<?php

namespace Advert\Controller;

use Common\Controller\AdminbaseController;
use SystemRecord\Model\SystemRecordModel;

class StatusController extends AdminbaseController {

    protected $AdvertData;

    public function _initialize() {
        parent::_initialize();
        $this->order = D("Order/Order");
        $this->AdvertData = D("Common/AdvertData");
        $this->page      = $_SESSION['set_page_row']?(int)$_SESSION['set_page_row']:20;
    }
    /**
     * 今日处理
     */
    public function today_process(){
        $where = array();
        $id_order_status = I('get.status_id');
        if ($id_order_status > 0) {
            $where['id_order_status'] = array('EQ',$id_order_status);
        } else {
            $where['id_order_status'] =  array('IN', array(3,4,10,11,12,13,14,15));
        }
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $data = $model->get_untreated_order_byusers($where);
        $department_id  = $_SESSION['department_id'];
        $admin_id = $_SESSION['ADMIN_ID'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $data['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page",$data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data['order_total']);
        //$this->assign("todayWebData", $data['todayWebData']);
        $this->assign("order_list",$data['order_list']);
        $this->assign("shipping",$data['shipping']);
        $this->assign("all_product",$data['all_product']);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看已处理订单');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("all_zone",$data['all_zone']);
        $this->display();
    }

    /**
     * 未处理订单
     */
    public function untreated(){
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $set_where = array('id_order_status'=>1,'payment_method'=>array('NOT IN','0'));
        $data = $model->get_untreated_order_byusers($set_where,true);
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $data['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page",$data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data['order_total']);
        //$this->assign("todayWebData", $data['todayWebData']);
        $this->assign("order_list",$data['order_list']);
        $this->assign("shipping",$data['shipping']);
        $this->assign("all_product",$data['allProduct']);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("all_zone",$data['all_zone']);
        $this->display();
    }

    /**
     * 待审核订单
     */
    public function pending(){
        $where = array('id_order_status'=>3);
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $data= $model->get_untreated_order_byusers($where);
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $data['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page",$data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data['order_total']);
        $this->assign("today_web_data", $data['today_web_data']);
        $this->assign("order_list",$data['order_list']);
        $this->assign("shipping",$data['shipping']);
        $this->assign("all_product",$data['all_product']);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看待审核订单');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("all_zone",$data['all_zone']);
        $this->display();
    }
    
    /*
     * 广告成效统计
     */
    public function effect() {
        
        $where = array();
        if (isset($_GET['start_time']) && $_GET['start_time']) {
            $createAtArray = array();
                $createAtArray[] = array('EGT', $_GET['start_time']);
            if($_GET['end_time']) {
                $createAtArray[] = array('LT', $_GET['end_time']);
            }
            $where[] = array('o.created_at' => $createAtArray);
        } 
        else {
            $all_day = $this->get_the_month(date('Y-m-d', strtotime('-1 month')));
            $createAtArray = array();
            $createAtArray[] = array('EGT', $all_day['first']);
            $createAtArray[] = array('LT', $all_day['last']);
            $where[] = array('o.created_at' => $createAtArray);
        }
        
        $department_id = M('Department')->where(array('id_users'=>$_SESSION['ADMIN_ID']))->getField('id_department');
        if($department_id) {
            $id_department = $department_id;
            $flag=1;//主管
        } else {            
            $id_department = $_SESSION['department_id'] ? $_SESSION['department_id'] : array();
            $users = M('Users')->field('id,superior_user_id')->where(array('superior_user_id'=>$_SESSION['ADMIN_ID']))->select();
            $user_id = array_column($users, 'id');
            if($user_id) {
                $flag=2;//组长
                array_push($user_id,$_SESSION['ADMIN_ID']);//把本身用户Id添加进去                
            } else {
                $flag=3;//组员
                $user_id = $_SESSION['ADMIN_ID'];
            }
            $where['o.id_users'] = array('IN',$user_id);
            $dwhere['id_users'] = array('IN',$user_id);
            $uwhere['id'] = array('IN',$user_id);
        }        
        //组长搜索组员
        $user_result = M('Users')->field('id,user_nicename')->where($uwhere)->select();
        $user_names = array_column($user_result, 'user_nicename', 'id');
        
        //选择名称
        if (isset($_GET['user_id']) && $_GET['user_id']) {
            $where[] = array('o.id_users' => $_GET['user_id']);
        }          
        //搜索名称
        if(isset($_GET['user_name']) && $_GET['user_name']) {
            $user_name = M('Users')->field('id')->where(array('user_nicename'=>array('LIKE', '%' . $_GET['user_name'] . '%')))->select();
            $user_name = array_column($user_name, 'id');
            $where['o.id_users'] = array('IN',$user_name);
        }
        //选择域名
        if (isset($_GET['domain_id']) && $_GET['domain_id']) {
            $where[] = array('o.id_domain' => $_GET['domain_id']);
        }       
        
        $M = new \Think\Model();
        $order_tab = M('Order')->getTableName();
        $advert_tab = M('Advert')->getTableName();
        $advert_data_tab = M('AdvertData')->getTableName(); 
        $order_item_tab = M('OrderItem')->getTableName();
        $product = M('Product')->getTableName();
                
        $shipping = M('Shipping')->where(array('id_shipping'=>25))->find();//天马物流
        
        $where['o.id_department'] = array('IN',$id_department); 
        $dwhere['id_department'] = array('IN',$id_department);      
        
        $field = 'SUBSTRING(o.created_at,1,10) AS create_date,o.id_users,o.id_domain,o.id_order,o.currency_code,
                SUM(IF(o.id_order_status IN(4,5,6,7,8,9,10,16),1,0)) as effective,
                SUM(IF(o.id_order_status IN(4,5,6,7,8,9,10,16),o.price_total,0)) as effective_price';

        $result_count = $M->table($order_tab.' as o')->field($field)
                ->where($where)
                ->group('create_date,o.id_domain')
                ->order('create_date DESC,o.id_users ASC,o.id_domain ASC')
                ->select();

        $page = $this->page(count($result_count), 40);
        
        $result = $M->table($order_tab.' as o')->field($field)
                ->where($where)
                ->group('create_date,o.id_domain')
                ->order('create_date DESC,o.id_users ASC,o.id_domain ASC')
                ->limit($page->firstRow . ',' . $page->listRows)->select();

//        print_r($result);die;
        foreach ($result as $k=>$v) {
            $expense = $M->table($advert_tab.' as a')->join('LEFT JOIN '.$advert_data_tab.' as ad ON ad.advert_id=a.advert_id')->field('ad.expense')
                        ->where(array('a.id_users'=>$v['id_users'],'a.id_domain'=>$v['id_domain']))->find();
            
            $product_result = $M->table($order_item_tab.' as oi')->join('LEFT JOIN '.$product.' as p ON p.id_product=oi.id_product')->field('p.weight,oi.quantity,p.purchase_price')
                                ->where(array('oi.id_order'=>$v['id_order']))->find();
            
            $result[$k]['effective_price'] = $this->get_exchange_rate($v['currency_code'], $v['effective_price']);            
            $result[$k]['expense'] = $expense['expense'];//广告费
            $result[$k]['weight'] = $product_result['weight'];//产品重量
            $result[$k]['quantity'] = $product_result['quantity'];//产品件数
            $result[$k]['purchase_price'] = $product_result['purchase_price'];//产品采购价
            $result[$k]['name'] = M('Users')->where(array('id'=>$v['id_users']))->getField('user_nicename');//名称
            $result[$k]['domain'] = M('Domain')->where(array('id_domain'=>$v['id_domain']))->getField('name');//域名
            //单个运费
            $result[$k]['freight'] = get_freight($v['weight'], $shipping['first_weight'], $shipping['first_weight_price'], $shipping['continued_weight'], $shipping['continued_weight_price']);
        }
        
        $arr_result = array();
        foreach ($result as $key=>$val) {
            if(empty($val['effective']) || empty($val['effective_price'])) continue;
            $arr_result[$val['create_date']][] = $val;
        }
        
        $total_effective=0;//总计有效单
        $total_effective_price=0;//总计营业额
        $total_advert_price=0;//总计广告费
        $total_freight=0;//总计运费
        $total_purchase_price=0;//总计采购价
        $total_qty=0;//总计数量
        foreach ($arr_result as $r_key=>$r_val) {
            foreach ($r_val as $key=>$val) {
                $total_effective+=$val['effective'];
                $total_effective_price+=$val['effective_price'];
                $total_advert_price+=$val['expense'];
                $total_freight+=$val['freight'];
                $total_purchase_price+=$val['purchase_price'];
                $total_qty+=$val['quantity'];
            }
        }
        $total_price = round($total_effective_price/$total_effective,2);//总计客单价
        $total_ad_average_price = round($total_advert_price/$total_effective,2);//总计平均广告费
        $total_roi = $total_advert_price != 0 ? round($total_effective_price/$total_advert_price,2) : 0;//总计ROI
        
        $tReturns = ($total_effective_price/($total_advert_price+($total_freight*$total_qty)+($total_purchase_price*$total_qty)));
        $total_tzhb = round($tReturns,2).'%';//投资回报率
        
        $Returns = (($total_effective_price-$total_advert_price-$total_freight*$total_qty)-($total_purchase_price*$total_qty))/($total_effective_price*0.8);
        $total_lr = round($Returns,2).'%';//利润率         
        
        $domain = M('Order')->field('id_domain')->where($dwhere)->select();
        $id_domain = array_column($domain, 'id_domain');
        $id_domain = array_unique($id_domain);
        if($id_domain){
            $domain_name = M('Domain')->field('id_domain,name')->where(array('id_domain'=>array('IN',$id_domain),'id_department'=>array('IN',$id_department)))->order('name ASC')->select();
            $domain_name = array_column($domain_name, 'name', 'id_domain');
        }
        
        add_system_record($_SESSION['ADMIN_ID'], 4, 3, '查看广告成效统计');
        $this->assign('list',$arr_result);
        $this->assign('domain_name',$domain_name);
        $this->assign("page", $page->show('Admin'));
        $this->assign('total_effective',$total_effective);
        $this->assign('total_effective_price',$total_effective_price);
        $this->assign('total_advert_price',$total_advert_price);
        $this->assign('total_price',$total_price);
        $this->assign('total_ad_average_price',$total_ad_average_price);
        $this->assign('total_roi',$total_roi);
        $this->assign('total_tzhb',$total_tzhb);
        $this->assign('total_lr',$total_lr);
        $this->assign('flag',$flag);
        $this->assign('user_names',$user_names);
        $this->display();
    }
    
    //获取指定日期所在月的第一天和最后一天
    protected function get_the_month($date) {
        $firstday = date("Y-m-01", strtotime($date));
        $lastday = date("Y-m-d", strtotime("$firstday +1 month -1 day"));
        return array('first' => $firstday, 'last' => $lastday);
    }
    
    protected function get_exchange_rate($currency_code,$price) {
        if($currency_code && $price) {
            switch ($currency_code) {
                case 'TWD':
                    $prices = round($price/4.6,2);//台币汇率
                break;
                case 'HKD':
                    $prices = round($price*0.91,2);//港币汇率
                break;
                case 'NTD':
                    $prices = round($price/4.6,2);//新台币汇率
                break;
                case 'SGD':
                    $prices = round($price/0.2,2);//新加坡汇率
                break;
                case 'JPY':
                    $prices = round($price/16.9,2);//日元汇率
                break;
                default:
                    $prices = 0;
            }
            return $prices;
        }
    }
}
