<?php

namespace Advert\Controller;

use Common\Controller\AdminbaseController;
use SystemRecord\Model\SystemRecordModel;

class IndexController extends AdminbaseController {

    protected $AdvertData;

    public function _initialize() {
        parent::_initialize();
        $this->order = D("Order/Order");
        $this->AdvertData = D("Common/AdvertData");
        $this->page      = $_SESSION['set_page_row']?(int)$_SESSION['set_page_row']:20;
    }
    
    //总列表
    public function all_list(){
        $count = $this->AdvertData->count();
        $page = $this->page($count, 20);

        $data = $this->AdvertData->join('__USERS__ ON (__USERS__.id=__ADVERT_DATA__.id_users)')
                ->order(array("id_advert_data" => "desc"))
                ->limit($page->firstRow, $page->listRows)
                ->select();

        $this->assign("adverts", $data);
        $this->assign("Page", $page->show('Admin'));
        $this->assign("current_page", $page->GetCurrentPage());
        $this->display();
    }

    public function index() {
        $count = $this->AdvertData->count();
        $page = $this->page($count, 20);
        
        $dep = $_SESSION['department_id'];
        $dep = implode(',', $dep);
        $dep==8 ? '' : ($dep ? $map['id_department'] = array('IN', $dep) : '');

        $data = $this->AdvertData->join('__USERS__ ON (__USERS__.id=__ADVERT_DATA__.id_users)')
                ->where($map)
                ->order(array("id_advert_data" => "desc"))
                ->limit($page->firstRow, $page->listRows)
                ->select();
        add_system_record(sp_get_current_admin_id(), 4, 3, '查看广告数据列表');
        $this->assign("adverts", $data);
        $this->assign("Page", $page->show('Admin'));
        $this->assign("current_page", $page->GetCurrentPage());
        $this->display();
    }

    /**
     * 添加
     */
    public function add() {
        $id = intval(I("get.id"));
        if ($id == 0) {
            $id = intval(I("post.id"));
        }

        //TODO: 修改只显示广告手用户
//        $role = D('Common/Role');
//        $users = D('Common/Users')
//            ->join('__ROLE_USER__ ON (__ROLE_USER__.user_id=__USERS__.id)')
//            ->join('__ROLE__ ON (__ROLE__.id=__ROLE_USER__.role_id)')
//            ->where($role->getTableName().'.id IN (5,6)')
//            ->select();
        $dep = $_SESSION['department_id'];
        $dep = implode(',', $dep);
        $dep==8 ? '' : ($dep ? $map['id_department'] = array('IN', $dep) : '');
        $list = D("Common/Department")->where($map)->order('id_department ASC')
                ->select();
        
        $users = D('Common/Users')->select();

        $this->assign("list", $list);
        $this->assign('users', $users);
        $this->display();
    }

    /**
     * 添加逻辑
     */
    public function add_post() {

        if (IS_POST) {
            $data = I('post.');
            $data['id_advert'] = 1;
            $data['created_at'] = date('Y-m-d H:i:s');
            if ($this->AdvertData->create($data)) {
                if ($this->AdvertData->add($data)) {
                    add_system_record(sp_get_current_admin_id(), SystemRecordModel::TYPE_INSER, SystemRecordModel::PRODUCT, '添加广告数据成功');
                    $this->success("添加成功", U("Index/index"));
                } else {
                    add_system_record(sp_get_current_admin_id(), SystemRecordModel::TYPE_INSER, SystemRecordModel::PRODUCT, '添加广告数据失败');
                    $this->error("添加失败！");
                }
            } else {
                $this->error($this->AdvertData->getError());
            }
        }
    }

    /**
     * 编辑
     */
    public function edit() {
        $id = intval(I("get.id"));
        if ($id == 0) {
            $id = intval(I("post.id"));
        }

        $users = D('Common/Users')->select();

        $dep = $_SESSION['department_id'];
        $dep = implode(',', $dep);
        $dep==8 ? '' : ($dep ? $map['id_department'] = array('IN', $dep) : '');
        $list = D("Common/Department")->where($map)->order('id_department ASC')
                ->select();

        $dom_table_name = $this->AdvertData->getTableName();
        $dep_table_name = D("Common/Department")->getTableName();
        $data = $this->AdvertData->table($dom_table_name . ' AS d LEFT JOIN ' . $dep_table_name . ' AS u ON d.id_department=u.id_department')->field('d.*,u.id_department,u.title')->where(array("id_advert_data" => $id))->find();

        if (!$data) {
            $this->error("该广告数据不存在！");
        }
        
        $this->assign('users', $users);
        $this->assign("advert", $data);
        $this->assign("list", $list);
        $this->display();
    }

    /**
     * 编辑
     */
    public function edit_post() {
        $id = intval(I("get.id"));
        if ($id == 0) {
            $id = intval(I("post.id_advert_data"));
        }
 
        if (IS_POST) {
            $data = I('post.');
            $data['updated_at'] = date('Y-m-d H:i:s'); 
            if ($this->AdvertData->create($data)) {
                if ($this->AdvertData->save($data) !== false) {
                    add_system_record(sp_get_current_admin_id(), SystemRecordModel::TYPE_EDIT, SystemRecordModel::PRODUCT, '修改广告数据'.$id.'成功');
                    $this->success("修改成功！", U('Index/index'));
                } else {
                    add_system_record(sp_get_current_admin_id(), SystemRecordModel::TYPE_EDIT, SystemRecordModel::PRODUCT, '修改广告数据'.$id.'失败');
                    $this->error("修改失败！");
                }
            } else {
                $this->error($this->AdvertData->getError());
            }
        }
    }

    /**
     * 删除
     */
    public function delete() {
        $id = intval(I("get.id"));
        
        $status = $this->AdvertData->delete($id);
        if ($status!==false) {
            add_system_record(sp_get_current_admin_id(), SystemRecordModel::TYPE_DELETE, SystemRecordModel::PRODUCT, '删除广告数据'.$id.'成功');
            $this->success("删除成功！", U('index/index'));
        } else {
            add_system_record(sp_get_current_admin_id(), SystemRecordModel::TYPE_DELETE, SystemRecordModel::PRODUCT, '删除广告数据'.$id.'失败');
            $this->error("删除失败！");
        }
    }
    /*
     * 订单列表
     */


    public function all_order() {
        /** @var \Order\Model\OrderModel $order_model */
        $order_model = $this->order;
        $where = $order_model->form_where($_GET);
        $department_id = isset($_SESSION['department_id'])?$_SESSION['department_id']:array(0);
        $admin_id = $_SESSION['ADMIN_ID'];
        $where['id_users'] = $admin_id;
        $where['id_department'] = isset($_GET['id_department']) && $_GET['id_department'] != ''?array('EQ',$_GET['id_department']):array('IN',$department_id);
        if(isset($_GET['id_department']) && $_GET['id_department']){
            $where['id_department']= $_GET['id_department'];
        }

        $where['payment_method'] = array('EQ','0');
        $today_date = date('Y-m-d 00:00:00');
        $form_data = array();
        /** @var \Domain\Model\DomainModel $domain_model */
        $domain_model = D('Domain/Domain');
        $form_data['domain'] = $domain_model->get_all_domain();

        //$formData['product_type'] = $baseSql->getFieldGroupData('product_type');
        $form_data['track_status'] = D('Order/OrderShipping')->field('status_label as track_status')
            ->where("status_label is not null or status_label !='' ")
            ->group('status_label')->cache(true, 12000)->select();


        //今日统计订单 条件
        $today_where = $where;
        $today_where['created_at'] = array('EGT', $today_date);
        $all_domain_total = $order_model->field('count(`id_domain`) as total,id_domain')->where($today_where)
            ->order('total desc')->group('id_domain')->select();

        //修改过滤物流状态， 当不需要过滤物流状态时，很卡，所以需要判断是否需要过滤物流状态
        if (isset($where['status_label']) && $where['status_label']) {
            $count = $order_model->alias('o')
                ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.order_id)', 'LEFT')
                ->where($where)->count();
            $today_total = $order_model->alias('o')
                ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.order_id)', 'LEFT')
                ->where($today_where)->count();
            $page = $this->page($count, $this->page);
            $order_list = $order_model->alias('o')->field('o.*,oi.ip as ip ,s.signed_for_date')
                ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.order_id)', 'LEFT')
                ->join('__ORDER_INFO__ as oi ON (o.id_order = oi.id_order)', 'LEFT')
                ->where($where)->order("id_order DESC")->limit($page->firstRow . ',' . $page->listRows)->select();
        } else {
            $count = $order_model->where($where)->count();
            $today_total = $order_model->where($today_where)->count();
            $page = $this->page($count, $this->page);
            $order_list = $order_model->alias('o')->field('o.*,oi.ip as ip')->join('__ORDER_INFO__ as oi ON (o.id_order = oi.id_order)', 'LEFT')->where($where)->order("id_order DESC")->limit($page->firstRow . ',' . $page->listRows)->select();
        }
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        foreach ($order_list as $key => $o) {
            $order_list[$key]['products'] = $order_item->get_item_list($o['id_order']);
            $order_list[$key]['total_price'] = \Common\Lib\Currency::format($o['price_total'],$o['currency_code']);
        }
        $advertiser = D('Common/Users')->field('id,user_nicename as name')->cache(true,36000)->select();
        $advertiser = array_column($advertiser,'name','id');
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        add_system_record($_SESSION['ADMIN_ID'], 4, 4,'查看订单列表');
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $advertiser);
        $this->assign("get", $_GET);
        $this->assign("form_data", $form_data);
        $this->assign("page", $page->show('Admin'));
        $this->assign("today_total", $today_total);
        $this->assign("order_total", $count);
        $this->assign("all_domain_total", $all_domain_total);

        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("order_list", $order_list);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    public function info(){
        $order_id = I('get.id');
        $order = D("Order/Order")->find($order_id);
        $statusLabel = D("Order/OrderStatus")->get_status_label();
        $orderHistory = D("Order/OrderRecord")
            ->field('*')
            ->join('__USERS__ u ON (__ORDER_RECORD__.id_users = u.id)', 'LEFT')
            ->where(array('id_order'=>$order_id))
            ->order('created_at desc')->select();
        $shipping = D('Common/Shipping')
            ->where(array('id_shipping'=>(int)$order['id_shipping']))->cache(true,3600)
            ->find();
        /** @var \Domain\Model\DomainModel $domain_model */
        $domain_model = D('Domain/Domain');
        $all_domain = $domain_model->get_all_domain();
        $order['id_domain'] = $all_domain[$order['id_domain']];
        $order['id_order_status'] = $statusLabel[$order['id_order_status']];
        $products = D('Order/OrderItem')->get_item_list($order['id_order']);
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看订单详情');
        $this->assign("order", $order);
        $this->assign("products", $products);
        $this->assign("history", $orderHistory);
        $this->assign("label", $statusLabel);
        $this->assign('shipping_name', $shipping['title']);
        $this->assign('shopping_url', $shipping['track_url']);
        $this->display();
    }

    /**
     * 导出订单列表
     */
    public function export_search() {
        vendor("PHPExcel.PHPExcel");
        vendor("PHPExcel.PHPExcel.IOFactory");
        vendor("PHPExcel.PHPExcel.Writer.CSV");
        $excel = new \PHPExcel();

        $column = array(
            '地区', '域名', '订单号', '姓名', '电话号码', '邮箱',
            '产品名和价格', '总价（NTS）', '属性',
            '送货地址', '购买产品数量', '留言备注', '下单时间', '订单状态',
            '发货日期', '运单号', '物流状态'
        );
        $j = 65;
        foreach ($column as $col) {
            $excel->getActiveSheet()->setCellValue(chr($j) . '1', $col);
            ++$j;
        }
        $where = $this->order->form_where($_GET);
        $department_id = isset($_SESSION['department_id'])?$_SESSION['department_id']:array(0);
        $where['id_department'] = isset($_GET['id_department']) && $_GET['id_department'] != ''?array('EQ',$_GET['id_department']):array('IN',$department_id);
        if(isset($_GET['id_department']) && $_GET['id_department']){
            $where['id_department']= $_GET['id_department'];
        }

        $orders = $this->order
            ->where($where)
            ->order("id_order ASC")
            ->limit(5000)->select();
        $result = D('Order/OrderStatus')->select();
        $status = array();
        foreach ($result as $statu) {
            $status[(int) $statu['id_order_status']] = $statu;
        }
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        $idx = 2;
        foreach ($orders as $o) {
            $product_name = '';
            $attrs = '';
            $products = $order_item->get_item_list($o['id_order']);
            $product_count = 0;
            foreach ($products as $p) {
                $product_name .= $p['product_title'] . "\n";
                if($p['sku_title']) {
                    $attrs .= $p['sku_title']. ' x ' . $p['quantity'] . ",";
                } else {
                    $attrs .= $p['product_title']. ' x ' . $p['quantity'] . ",";
                }
                $product_count +=$p['quantity'];
            }
            $attrs = trim($attrs, ',');
            $status_name = isset($status[$o['id_order_status']]) ? $status[$o['id_order_status']]['title'] : '未知';
            $domain_title = D('Domain/Domain')->where(array('id_domain'=>$o['id_domain']))->getField('name');
            $getShipObj = D("Order/OrderShipping")->field('track_number,status_label')->where('id_order=' . $o['id_order'])->select();
            $trackNumber = $getShipObj ? implode(',', array_column($getShipObj, 'track_number')) : '';
            $trackStatusLabel = $getShipObj ? implode(',', array_column($getShipObj, 'status_label')) : '';
            $data = array(
                $o['province'], $domain_title, $o['id_increment'], $o['first_name'], $o['tel'], $o['email'],
                $product_name, $o['price_total'], $attrs,
                $o['address'], $product_count, $o['remark'], $o['created_at'], $status_name,
                $o['date_delivery'], ' ' . $trackNumber, $trackStatusLabel
            );
            $j = 65;
            foreach ($data as $col) {
                $excel->getActiveSheet()->setCellValue(chr($j) . $idx, $col);
                ++$j;
            }
            ++$idx;
        }
        add_system_record(sp_get_current_admin_id(), 6, 4, '导出DF订单列表');
        $excel->getActiveSheet()->setTitle(date('Y-m-d') . '订单信息.xlsx');
        $excel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . date('Y-m-d') . '订单信息.xlsx"');
        header('Cache-Control: max-age=0');
        $writer = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $writer->save('php://output');exit();
    }
	/*
     * 广告列表
     */
    public function all_advert(){
        $current_user = $_SESSION['ADMIN_ID'];
        $department_id = implode(',',$_SESSION['department_id']);
        $where['id_department'] = array('EQ',$department_id);
        $dep_user = M('department')->where($where)->getField('id_users');
        //小主管
        $group['superior_user_id'] = array('EQ',$current_user);
        $group_user = M('Users')->field('id')->where($group)->select();
        //是部门主管
        $user_list_data = '';
        if($current_user==$dep_user)
        {
            $cond['id_department'] = array('EQ',$department_id);
            $user_list = M('DepartmentUsers')->field('id_users')->where($cond)->select();
            foreach($user_list as $v){
                $user_list_data .= $v['id_users'].',';
            }
            $user_list_data = rtrim($user_list_data,',');
            $con['id_users'] = array('IN',$user_list_data);
            $count =M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')->where($con)->count();
            $page = $this->page($count, 20);
            $adverts = M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')->where($con)->limit($page->firstRow . ',' . $page->listRows)->select();
        }elseif($group_user!==false){
            //是否是组长

            foreach($group_user as $v){
                $user_list_data .= $v['id'].',';
            }
            $user_list_data .= $current_user;
            $con['id_users'] = array('IN',$user_list_data);
            $count =M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')->where($con)->count();
            $page = $this->page($count, 20);
            $adverts = M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')->where($con)->limit($page->firstRow . ',' . $page->listRows)->select();
        }else{
            $con['id_users'] = array('EQ',$current_user);
            $count =M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')->where($con)->count();
            $page = $this->page($count, 20);
            $adverts = M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')->where($con)->limit($page->firstRow . ',' . $page->listRows)->select();
        }

        $users_data = M('Users')->field('id,user_nicename,superior_user_id')->select();
        $users = '';
        foreach($users_data as $v){
            $users[$v['id']] = $v;
        }
        $this->assign('users',$users);
        $this->assign('adverts',$adverts);
        $this->assign("Page", $page->show('Admin'));
        $this->assign("current_page", $page->GetCurrentPage());
        $this->display();
    }
    /*
  * 费用列表
  */
    public function all_cost(){
        $previous_day = date("Y-m-d",strtotime("-1 day"));
        $conversion_at = array();
        $conversion_at[]= array('EGT',$previous_day);
        $conversion_at[]= array('ELT',$previous_day);
        $where['conversion_at']= $conversion_at;
        if(IS_GET){

            if(isset($_GET['id_domain'])&&$_GET['id_domain'])
                $where['id_domain'] = array('EQ',$_GET['id_domain']);
            if(isset($_GET['advert_name'])&&$_GET['advert_name'])
                $where['advert_name'] = array('LIKE',$_GET['advert_name']);
            if ($_GET['start_conversion_at'] or $_GET['end_conversion_at']) {
                $conversion_at = array();
                if ($_GET['start_conversion_at'])
                    $conversion_at[]= array('EGT',$_GET['start_conversion_at']);
                if ($_GET['end_conversion_at'])
                    $conversion_at[]= array('ELT',$_GET['end_conversion_at']);
                $where['conversion_at']= $conversion_at;
            }
        }
        $current_user = $_SESSION['ADMIN_ID'];
        $department_id = implode(',',$_SESSION['department_id']);
        $dep_where['id_department'] = array('EQ',$department_id);
        $dep_user = M('department')->where($dep_where)->getField('id_users');
        //小主管
        $group_where['superior_user_id'] = array('EQ',$current_user);
        $group_user = M('Users')->field('id')->where($group_where)->select();
        //是部门主管
        $user_list_data = '';
        if($current_user==$dep_user)
        {
            $cond['id_department'] = array('EQ',$department_id);
            $user_list = M('DepartmentUsers')->field('id_users')->where($cond)->select();
            foreach($user_list as $v){
                $user_list_data .= $v['id_users'].',';
            }
            $user_list_data = rtrim($user_list_data,',');
            if(isset($_GET['id_users'])&&$_GET['id_users']) $where['id_users'] = array('EQ',$_GET['id_users']);
            else $where['id_users'] = array('IN',$user_list_data);
            $count =M('Advert')->field('a.id_users,a.id_domain,a.advert_name,a.url,ad.*')
                ->alias('a')->join('__ADVERT_DATA__ as ad on ad.advert_id = a.advert_id','LEFT')->where($where)->order('conversion_at DESC')->count();
            $page = $this->page($count, 20);
            $costs = M('Advert')->field('a.id_users,a.id_domain,a.advert_name,a.url,ad.*')
                ->alias('a')->join('__ADVERT_DATA__ as ad on ad.advert_id = a.advert_id','LEFT')->where($where)->order('conversion_at DESC')->limit($page->firstRow, $page->listRows)->select();

        }elseif($group_user!==false){
            //是否是组长
            foreach($group_user as $v){
                $user_list_data .= $v['id'].',';
            }
            $user_list_data .= $current_user;
            if(isset($_GET['id_users'])&&$_GET['id_users']) $where['id_users'] = array('EQ',$_GET['id_users']);
            else $where['id_users'] = array('IN',$user_list_data);
            $count = M('Advert')->field('a.id_users,a.id_domain,a.advert_name,a.url,ad.*')
                ->alias('a')->join('__ADVERT_DATA__ as ad on ad.advert_id = a.advert_id','LEFT')->where($where)->order('conversion_at DESC')->count();
            $page = $this->page($count, 20);

            $costs = M('Advert')->field('a.id_users,a.id_domain,a.advert_name,a.url,ad.*')
                ->alias('a')->join('__ADVERT_DATA__ as ad on ad.advert_id = a.advert_id','LEFT')->where($where)->order('conversion_at DESC')->limit($page->firstRow, $page->listRows)->select();
        }else{

            if(isset($_GET['id_users'])&&$_GET['id_users']) $where['id_users'] = array('EQ',$_GET['id_users']);
            else $where['id_users'] = array('EQ',$current_user);
            $count = M('Advert')->field('a.id_users,a.id_domain,a.advert_name,a.url,ad.*')
                ->alias('a')->join('__ADVERT_DATA__ as ad on ad.advert_id = a.advert_id','LEFT')->where($where)->order('conversion_at DESC')->count();
            $page = $this->page($count, 20);
            $costs = M('Advert')->field('a.id_users,a.id_domain,a.advert_name,a.url,ad.*')
                ->alias('a')->join('__ADVERT_DATA__ as ad on ad.advert_id = a.advert_id','LEFT')->where($where)->order('conversion_at DESC')->limit($page->firstRow, $page->listRows)->select();
//            echo $costs;die;


        }
        $datas['users'] = array_unique(array_column($costs,'id_users'));
        $datas['domains'] = array_unique(array_column($costs,'id_domain'));
        $datas['advert_name'] = array_unique(array_column($costs,'advert_name'));

//        asort($datas['advert_name'],SORT_STRING);
        $users = '';
        $users_data = M('Users')->field('id,user_nicename,superior_user_id')->select();
        foreach($users_data as $v){
            $users[$v['id']] = $v;
        }
        $user_list_data = explode(',',$user_list_data);
        $department_id = $_SESSION['department_id'];
        $department_id = implode(',',$department_id);
        $where['id_department'] = array('IN',$department_id);
        $department = D('Domain/Domain')->where($where)->select();
        $departments = array_column($department,'name','id_domain');
        $this->assign('datas',$datas);
        $this->assign('user_list_data',$user_list_data);
        $this->assign('users',$users);
        $this->assign('departments',$departments);
        $this->assign('costs',$costs);

        $this->assign("Page", $page->show('Admin'));
        $this->assign("current_page", $page->GetCurrentPage());
        $this->display();
    }
    /*
    * 添加广告
    */
    public function add_advert(){
        $department_id = $_SESSION['department_id'];
        $department_id = implode(',',$department_id);
        $where['id_department'] = array('IN',$department_id);
        $department = D('Domain/Domain')->where($where)->order('name')->select();
        $departments = array_column($department,'name','id_domain');
        $this->assign('departments',$departments);
        if(IS_POST){
            $_POST['id_users']=$_SESSION['ADMIN_ID'];
            $_POST['created_at'] = date('Y-m-d H:i:s');

            $res =  M('Advert')->add($_POST);
            if ($res == false) {
                $this->error("保存失败！", U('index/add_advert', array('advert_id' =>$res)));
            }
            $this->success("保存完成！", U('index/add_advert', array('advert_id' =>$res)));
        }
        if(IS_GET){
            $where['advert_id'] = $_GET['advert_id'];
            $advert = M('Advert')->where($where)->find();
            $this->assign('advert',$advert);
        }

        $this->display();
    }
    /*
    * 添加数据
    */
    public function add_data(){
        if(IS_GET){
            if($_GET['advert_id']){
                $where['advert_id'] = array('EQ',$_GET['advert_id']);
                $advert = M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain')
                    ->where($where)->find();
                $this->assign('advert',$advert);
            }
            if($_GET['id_advert_data']!=''){
                $where['id_advert_data'] = array('EQ',$_GET['id_advert_data']);
                $advert = M('Advert')->alias('a')->field('a.*,d.name,ad.*')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')
                                     ->join('__ADVERT_DATA__ as ad on a.advert_id = ad.advert_id')
                                     ->where($where)->find();
                $this->assign('advert',$advert);

            }


        }
        if(IS_POST){
            if($_POST['id_advert_data']==''){
                $add['advert_id'] = $_POST['advert_id'];
                $add['conversion'] = $_POST['conversion'];
                $add['cost'] = $_POST['cost'];
                $add['expense'] = $_POST['expense'];
                $add['cmp'] = $_POST['cmp'];
                $add['ctr'] = $_POST['ctr'];
                $add['created_at'] = date('Y-m-d H:i:s');
                $add['conversion_at'] = $_POST['conversion_at'];
                $res = M('AdvertData')->add($add);
                if ($res == false) {
                    $this->error("保存失败！", U('index/add_data', array('id_advert_data' =>$res)));
                }
                $this->success("保存完成！", U('index/add_data',array('id_advert_data' =>$res)));
            }
            else{
                $update['id_advert_data'] = $_POST['id_advert_data'];
                $update['advert_id'] = $_POST['advert_id'];
                $update['conversion'] = $_POST['conversion'];
                $update['cost'] = $_POST['cost'];
                $update['expense'] = $_POST['expense'];
                $update['cmp'] = $_POST['cmp'];
                $update['ctr'] = $_POST['ctr'];
                $update['update_at'] = date('Y-m-d H:i:s');
                $update['conversion_at'] = $_POST['conversion_at'];
                $res = M('AdvertData')->save($update);
//                var_dump($res);die;
                if ($res == false) {
                    $this->error("修改失败！", U('index/add_data', array('id_advert_data' =>$_POST['id_advert_data'])));
                }
                $this->success("修改完成！", U('index/add_data',array('id_advert_data' =>$_POST['id_advert_data'])));

            }

        }
        $this->display();
    }
    /*
     * 编辑广告
     */
    public function edit_advert(){
        if(IS_GET){
            $where = array();
            $where['advert_id'] = array('EQ',$_GET['advert_id']);
            $advert = M('Advert')->alias('a')->field('a.*,d.name')->join('__DOMAIN__ as d on a.id_domain = d.id_domain')
                                  ->where($where)->find();
            $this->assign('advert',$advert);
        }
        if(IS_POST){
            $update = $_POST;
            $where['advert_id']= $_POST['advert_id'];
            $update['update_at'] = date('Y-m-d H:i:s');
            $res = M('Advert')->where($where)->save($update);
            if ($res == false) {
                $this->error("保存失败！", U('index/edit_advert', array('advert_id' => $_POST['advert_id'])));
            }
            $this->success("保存完成！", U('index/edit_advert', array('advert_id' => $_POST['advert_id'])));
//            add_system_record($_SESSION['ADMIN_ID'], 2, 3, '编辑广告');
        }

        $this->display();
    }

    /*
     * 添加费用
     */
    public function add_cost(){
        $previous_day = date("Y-m-d",strtotime("-1 day"));
        $conversion_at = array();
        $post_at[]= array('EGT',$previous_day);
        $post_at[]= array('ELT',$previous_day);
        $where['post_at']= $post_at;
        if ($_GET['start_time'] or $_GET['end_time']) {
            $post_at = array();
            if ($_GET['start_time'])
                $post_at[]= array('EGT',$_GET['start_time']);
            if ($_GET['end_time'])
                $post_at[]= array('ELT',$_GET['end_time']);
            $where['post_at']= $post_at;
        }

        $department_id = $_SESSION['department_id'];
        $department_id = implode(',',$department_id);
        $where['id_department'] = array('IN',$department_id);
        $department = D('Domain/Domain')->where($where)->select();
        $departments = array_column($department,'name','id_domain');
        $res = 0;
        if(IS_POST){
            foreach($_POST['data'] as $v){
                if(empty($v['conversion'])||empty($v['conversion_at'])||empty($v['cost'])||empty($v['expense'])){
                   unset($v);continue;
                }
                $v['id_users'] = $_SESSION['ADMIN_ID'];
                $v['created_at'] = date('Y-m-d H:i:s');
                empty($v['cmp'])?$v['cmp']=null:$v['cmp'];
                empty($v['cmp'])?$v['ctr']=null:$v['ctr'];

                $res =  M('AdvertData')->add($v);

            }
            if ($res == false) {
                $this->error("添加失败", U('index/add_cost'));
            }
            $this->success("添加完成！", U('index/all_cost'));
        }
        $users = '';
        $users_data = M('Users')->field('id,user_nicename,superior_user_id')->select();
        foreach($users_data as $v){
            $users[$v['id']] = $v;
        }


        //分权限
        $current_user = $_SESSION['ADMIN_ID'];
        $department_id = implode(',',$_SESSION['department_id']);
        $dep_where['id_department'] = array('EQ',$department_id);
        $dep_user = M('department')->where($dep_where)->getField('id_users');
        //小主管
        $group['superior_user_id'] = array('EQ',$current_user);
        $group_user = M('Users')->field('id')->where($group)->select();
        //是部门主管
        $user_list_data = '';
        if($current_user==$dep_user)
        {
            $cond['id_department'] = array('EQ',$department_id);
            $user_list = M('DepartmentUsers')->field('id_users')->where($cond)->select();
            foreach($user_list as $v){
                $user_list_data .= $v['id_users'].',';
            }
            $user_list_data = rtrim($user_list_data,',');
            $where['id_users'] = array('IN',$user_list_data);

            $count =M('Advert')->where($where)->count();
            $page = $this->page($count, 20);
            $adverts =  M('Advert')->where($where)->limit($page->firstRow, $page->listRows)->select();
        }elseif($group_user!==false){
            //是否是组长
            foreach($group_user as $v){
                $user_list_data .= $v['id'].',';
            }
            $user_list_data .= $current_user;
            $where['id_users'] = array('IN',$user_list_data);
            $count =M('Advert')->where($where)->count();
            $page = $this->page($count, 20);
            $adverts =  M('Advert')->where($where)->select();
        }else{
            $where['id_users'] = array('EQ',$current_user);
            $count =M('Advert')->where($where)->count();
            $page = $this->page($count, 20);
            $adverts =  M('Advert')->where($where)->limit($page->firstRow, $page->listRows)->select();


        }

        $this->assign("Page", $page->show('Admin'));
        $this->assign("current_page", $page->GetCurrentPage());
        $this->assign('users',$users);
        $this->assign('departments',$departments);
        $this->assign('adverts',$adverts);
        $this->display();
    }
    public function edit_advert_data()
    {
        if(IS_GET){
            $where['id_advert_data'] = array('EQ',$_GET['id_advert_data']);
            $advert = M('Advert')->alias('a')->field('a.*,d.name,ad.*')->join('__DOMAIN__ as d on a.id_domain = d.id_domain','LEFT')
                ->join('__ADVERT_DATA__ as ad on a.advert_id = ad.advert_id')
                ->where($where)->find();
            $this->assign('advert',$advert);

        }
        if(IS_POST){
            $update['id_advert_data'] = $_POST['id_advert_data'];
            $update['advert_id'] = $_POST['advert_id'];
            $update['conversion'] = $_POST['conversion'];
            $update['cost'] = $_POST['cost'];
            $update['expense'] = $_POST['expense'];
            $update['cmp'] = $_POST['cmp'];
            $update['ctr'] = $_POST['ctr'];
            $update['update_at'] = date('Y-m-d H:i:s');
            $update['conversion_at'] = $_POST['conversion_at'];
            $res = M('AdvertData')->save($update);
//                var_dump($res);die;
            if ($res == false) {
                $this->error("修改失败！", U('index/edit_advert_data', array('id_advert_data' =>$_POST['id_advert_data'])));
            }
            $this->success("修改完成！", U('index/edit_advert_data',array('id_advert_data' =>$_POST['id_advert_data'])));

        }

        $this->display();
    }
}
