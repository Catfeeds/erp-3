<?php
/**
 * 仓库模块
 * @Author morrowind
 * @qq 752979972
 * Class IndexController
 * @package Warehouse\Controller
 */
namespace Warehouse\Controller;
use Common\Controller\AdminbaseController;
use SystemRecord\Model\SystemRecordModel;
use Order\Model\UpdateStatusModel;
class OrderController extends AdminbaseController {
    protected $Warehouse, $orderModel;
    public function _initialize() {
        parent::_initialize();
        $this->Warehouse = D("Common/Warehouse");
        $this->orderModel = D("Order/Order");
        $this->page = isset($_SESSION['set_page_row']) && $_SESSION['set_page_row']?$_SESSION['set_page_row']:20;
    }
    
    /*
     * 订单列表页
     */
    public function order_list() {
        $order_model = $this->orderModel;
        $where = $order_model->form_where($_GET);        
        if (isset($_GET['zone_id']) && $_GET['zone_id']) {
            $where['id_zone'] = $_GET['zone_id'];
        }
        if ($_GET['shipping_start_time'] or $_GET['shipping_end_time']) {

            $date_delivery_array = array();
            if ($_GET['shipping_start_time'])
                $date_delivery_array[] = array('EGT', $_GET['shipping_start_time']);
            if ($_GET['shipping_end_time'])
                $date_delivery_array[] = array('LT', $_GET['shipping_end_time']);
            $where['date_delivery'] = $date_delivery_array;
        }
        $today_date = date('Y-m-d 00:00:00');
        $form_data = array();
        /** @var \Domain\Model\DomainModel $domain_model */
        $domain_model = D('Domain/Domain');
        $form_data['domain'] = $domain_model->get_all_domain();

        //$formData['product_type'] = $baseSql->getFieldGroupData('product_type');
        $form_data['track_status'] = D('Order/OrderShipping')->field('status_label as track_status')
                        ->where("status_label is not null or status_label !='' ")
                        ->group('status_label')->cache(true, 12000)->select();
        /*if(empty($_GET['status_id'])){
            $where['id_order_status'] = array('IN',array(4, 5, 6, 7, 8, 9, 10, 14,17));
        }*/
        $form_data['shipping'] = D('Common/Shipping')->field('id_shipping,title')
            ->where("status=1 ")
            ->cache(true, 12000)->select();


        
        //今日统计订单 条件
        $today_where = $where;
        $today_where['created_at'] = array('EGT', $today_date);
        $all_domain_total = $order_model->field('count(`id_domain`) as total,id_domain')->where($today_where)
                        ->order('total desc')->group('id_domain')->select();

        //修改过滤物流状态， 当不需要过滤物流状态时，很卡，所以需要判断是否需要过滤物流状态
        if (isset($where['status_label']) && $where['status_label']) {
            $count = $order_model->alias('o')
                            ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.order_id)', 'LEFT')
                            ->where($where)->count();
            $today_total = $order_model->alias('o')
                            ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.order_id)', 'LEFT')
                            ->where($today_where)->count();
            $page = $this->page($count, $this->page);
            $order_list = $order_model->alias('o')->field('o.*,s.signed_for_date')
                            ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.order_id)', 'LEFT')
                            ->where($where)->order("id_order DESC")->limit($page->firstRow . ',' . $page->listRows)->select();
        } else {
            $count = $order_model->where($where)->count();
            $today_total = $order_model->where($today_where)->count();
            $page = $this->page($count, $this->page);
            $order_list = $order_model->where($where)->order("id_order DESC")->limit($page->firstRow . ',' . $page->listRows)->select();
        }
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        foreach ($order_list as $key => $o) {
            $order_list[$key]['products'] = $order_item->get_item_list($o['id_order']);
            $order_list[$key]['total_price'] = \Common\Lib\Currency::format($o['price_total'],$o['currency_code']);
            $order_list[$key]['shipping_name'] = D('Common/Shipping')->where('id_shipping='.$o['id_shipping'])->getField('title');
        }
        
        $department = M('Department')->where('type=1')->select();
        $zone = M('Zone')->select();
        $this->assign('zone',$zone);
        $this->assign('department',$department);
        $this->assign("get", $_GET);
        $this->assign("form_data", $form_data);
        $this->assign("page", $page->show('Admin'));
        $this->assign("today_total", $today_total);
        $this->assign("order_total", $count);
        $this->assign("all_domain_total", $all_domain_total);

        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus')->field('id_order_status,title')->where('status=1 and id_order_status IN (4,5,6,7,8,9,10,14,17)')->select();
        $status_model = array_column($status_model,'title','id_order_status');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看仓库订单列表');
        $this->assign('status_list',$status_model);
        $this->assign("order_list", $order_list);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }


    /*
     * 未配货订单
     */
    public function no_distribution_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /*
     * 配货中订单
     */
    public function in_distribution_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /*
     * 缺货订单
     */
    public function stockout_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /*
     * 已配货订单
     */
    public function fulfilled_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /**
        * 配送中订单
        */
    public function in_shipping_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /**
       * 已签收订单
       */
    public function received_order_list($status_id){
          $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /**
      * 已退货订单
      */
    public function return_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /**
     * 客户取消订单
      */
    public function cancel_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }
    /**
     * 部分缺货订单
     */
    public function partial_order_list($status_id){
        $status_id = $_GET['status_id'];
        $data =  D('Order/Order')->order_list_by_status($status_id);
        $this->assign('zone',$data['zone']);
        $this->assign('department',$data['department']);
        $this->assign("get", $data['get']);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page", $data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data[order_total]);
        $this->assign("all_domain_total", $data['all_domain_total']);
        $this->assign("order_list", $data['order_list']);
        $this->assign("status_list", $data['status_list']);
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->display();
    }

    /**
     * 订单详情
     */
    public function info(){
        $order_id = I('get.id');
        $order = D("Order/Order")->find($order_id);
        $statusLabel = D("Order/OrderStatus")->get_status_label();
        $orderHistory = D("Order/OrderRecord")
            ->field('*')
            ->join('__USERS__ u ON (__ORDER_RECORD__.id_users = u.id)', 'LEFT')
            ->where(array('id_order'=>$order_id))
            ->order('created_at desc')->select();
        $shipping = D('Common/Shipping')
            ->where(array('id_shipping'=>(int)$order['id_shipping']))
            ->find();
        /** @var \Domain\Model\DomainModel $domain_model */
        $domain_model = D('Domain/Domain');
        $all_domain = $domain_model->get_all_domain();
        $order['id_domain'] = $all_domain[$order['id_domain']];
        $order['id_order_status'] = $statusLabel[$order['id_order_status']];
        $products = D('Order/OrderItem')->get_item_list($order['id_order']);
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看仓库订单详情');
        $this->assign("order", $order);
        $this->assign("products", $products);
        $this->assign("history", $orderHistory);
        $this->assign("label", $statusLabel);
        $this->assign('shipping_name', $shipping['title']);
        $this->assign('shopping_url', $shipping['track_url']);
        $this->display();
    }

    /**
     * 编辑订单 from表单
     */
    public function edit_order() {
        $getId = I('get.id/i');
        //$department_id = isset($_SESSION['department_id']) ? $_SESSION['department_id'] : array(0);
        $where = array('id_order' => array('EQ', $getId));
        //$where['id_department'] = array('IN', $department_id);
        $order = $this->orderModel->where($where)->find();
        if(!$order){
            $this->error("你没有权限操作此订单！");
        }
        /** @var \Common\Model\ProductModel $product */
        $product = D('Common/Product');
        $order_item = D('Order/OrderItem');
        $products = $order_item->where(array(
            'id_order' => $order['id_order']
        ))->order('id_product desc')->select();
        /** @var  $options \Product\Model\ProductOptionModel */
        $options = D('Product/ProductOption');
        $all_attr = array();
        $arr_html = array();

        if ($products) {
            foreach ($products as $key => $product) {
                $product_id = $product['id_product'];
                if(!empty($product_id)) {
                    $sku_id = $product['id_product_sku'];
                    $arr_html[$product_id]['id_product'] = $product_id;
                    $arr_html[$product_id]['product_title'] = $product['product_title'];
                    $arr_html[$product_id]['id_order_item'] = $product['id_order_item'];
                    $arr_html[$product_id]['id_order_items'][$sku_id] = $product['id_order_item'];
                    $arr_html[$product_id]['quantity'][$sku_id] = $product['quantity'];
                    $arr_html[$product_id]['attrs'][$sku_id] = unserialize($product['attrs']);
                    $arr_html[$product_id]['attr_option_value'][$sku_id] = $product_id ? $options->get_attr_list_by_id($product_id) : '';
                    $arr_html[$product_id]['attr_option_value_data'] = $product_id ? $options->get_attr_list_by_id($product_id) : '';
                    $arr_html[$product_id]['sku_id'] = $product['id_product_sku'];
                    $products[$key]['attr_option_value'] = $all_attr[$product_id] ? $all_attr[$product_id] : $options->get_attr_list_by_id($product_id);
                    $all_attr[$product_id] = $all_attr[$product_id] ? $all_attr[$product_id] : $options->get_attr_list_by_id($product_id);
                }
            }
        }

        $this->assign("products", $arr_html);
        $this->assign("all_attr", $all_attr);
        $this->assign("order", $order);
        $this->display();
    }
    
    //编辑订单添加产品属性
    public function get_attr_html() {
        if(IS_AJAX) {
            $pro_id = I('post.id');
            $order_id = I('post.order_id');
            
            $order_item = D('Order/OrderItem');
            $products = $order_item->where(array(
                        'id_order' => $order_id
                    ))->order('id_product desc')->select();
            $options = D('Product/ProductOption');
            $all_attr = array();
            $select_attr = array();
            $select_num = array();
            
            if ($products) {
                foreach ($products as $key => $product) {                
                    $product_id = $product['id_product'];
                    if(!empty($product_id)) {
                        $sku_id = $product['id_product_sku'];
                        $select_attr[$product_id]['attrs'] = unserialize($product['attrs']);
                        $select_attr[$product_id]['quantity'] = $product['quantity'];
                        $all_attr[$product_id] = $all_attr[$product_id] ? $all_attr[$product_id] : $options->get_attr_list_by_id($product_id);
                    }
                }
            }
            
//            dump($select_attr);
            
            $html = '<tr class="productAttrRow'.$pro_id.'">';
            $html .= '<td>';
            foreach ($all_attr[$pro_id] as $k=>$val) {
                $html .= $val['title'].'&nbsp';
                $html .= '<select name="option_id['.$pro_id.']['.$val["id_product_option"].'][]">';
                foreach($val["option_values"] as $kk => $vv) {
                    $selected = in_array($vv['id_product_option_value'],$select_attr[$pro_id]['attrs']) ? 'selected' : '';  
                    $html .= '<option value ="'.$vv['id_product_option_value'].'" '.$selected.'>'.$vv['title'].'</option>';
                }
                $html .= '</select>&nbsp;&nbsp;&nbsp;';                    
            }
            $html .= '<input name="number['.$pro_id.'][]" value="'.$select_attr[$pro_id]['quantity'][0].'" type="text">&nbsp;&nbsp;';
            $html .= '<a href="javascript:void(1);" class="deleteOrderAttr" pro_id="'.$pro_id.'">删除</a>';
            $html .= '</td>';
            $html .= '</tr>';
            echo $html;die();
        }
    }

    /**
     * 处理编辑订单
     */
    public function edit_order_post() {
        $orderId = I('get.id');
        $order = D("Order/Order")->find($orderId);
        if (isset($_POST['action']) && $_POST['action'] == 'delete_attr') {
            //因为要添加权限，所以先写到这个控制器了。            
            $itemId = I('post.order_attr_id');
            if ($orderId && $itemId) {
                $deleteData = D("Order/OrderItem")->find($itemId);
                $comment = '删除产品属性：' . json_encode($deleteData);
                D("Order/OrderItem")->where('id_order_item=' . $itemId)->delete();
//                D('Order/Order')->where('id_order='.$orderId)->save(array('price_total'=>$order['price_total']-$deleteData['total']));
                D("Order/OrderRecord")->addHistory($orderId, $order['id_order_status'],3, $comment);
            }
            F('order_item_by_order_id_cache'.$orderId,null);
            exit();
        }
        
        if(IS_POST) {
            $data = I('post.'); 
//            dump($data['number']);die;
            D('Order/Order')->save($data);
            
            $product_id = array();
            foreach($data['option_id'] as $key=>$val){
                $product_id[] = $key;
                $temp = array();

                foreach($val as $k=>$v) {
                    foreach($v as $kk=>$vv){
                        $temp[$kk][] = $vv;                        
                    }                    
                }
                $product = D('Product/Product')->field('title,inner_name,sale_price')->where('id_product='.$key)->find();
                foreach($temp as $psk =>$psv)  { 
                    
                    $option_value = asort($psv);
                    $option_value = implode(',', $psv);
                    $product_sku = D('Product/ProductSku')->where("option_value='$option_value' and id_product=$key")->find();
                    $item_result = D('Order/OrderItem')->where('id_product='.$key.' and id_product_sku='.$product_sku['id_product_sku'].' and id_order='.$data['id_order'])->find();                                      
                    $item_data['id_order'] = $data['id_order'];
                    $item_data['id_product'] = $key;
                    $item_data['id_product_sku'] = $product_sku['id_product_sku']; 
                    $item_data['sku'] = $product_sku['sku'];
                    $item_data['sku_title'] = $product_sku['title'];
                    $item_data['sale_title'] = $product['title'];
                    $item_data['product_title'] = $product['title'];
                    $item_data['quantity'] = $data['number'][$key][$psk];
                    $item_data['price'] = $product['sale_price'];
                    $item_data['total'] = $product['sale_price']*$data['number'][$key][$psk];
                    $item_data['attrs'] = serialize($psv);
                    if(array_keys($data['order_item_id'][$key])[$psk] == $psk) {
                        D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$key][$psk])->data($item_data)->save();
                    } else {
                        if($product_sku['id_product_sku'] == $item_result['id_product_sku'] || empty($data['number'][$key][$psk])) continue;
                        D('Order/OrderItem')->data($item_data)->add();
                    }                    
                    if($data['number'][$key][$psk] == 0) {
                        D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$key][$psk])->delete();
                    }
                }
            } 

            foreach ($data['pro_id'] as $pro_key=>$pro_val) {
                if(!in_array($pro_val,$product_id)) {
                    $other_product = D('Product/Product')->field('title,inner_name,sale_price')->where('id_product='.$pro_val)->find();
                    $item_id = $data['order_item_id'][$pro_val][0];
                    $other_item_data['total'] = $other_product['sale_price']*$data['qty'.$pro_val];
                    $other_item_data['quantity'] = $data['qty'.$pro_val];
                    D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$pro_val][0])->data($other_item_data)->save();
                }

                if(isset($data['qty'.$pro_val]) && $data['qty'.$pro_val] == 0) {
                    D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$pro_val][0])->delete();
                }
            }      
            D("Order/OrderRecord")->addHistory($orderId, $order['id_order_status'],2, '仓库编辑订单属性');
            add_system_record(sp_get_current_admin_id(), 2, 1, '仓库编辑订单属性');
            F('order_item_by_order_id_cache'.$orderId,null);
            $this->success("保存完成！", U('order/edit_order', array('id' => $orderId)));
        } else {
            $this->error("参数不正确！");
        }
    }
    
    /**
     * 要求取消订单
     */
    public function cancel_order(){
        try{
            $order_id = I('post.order_id');
            $status_id = 14;
            $comment = '【仓储管理取消】 ';
            //D("Order/Order")->where(array('id_order'=>$order_id))->save(array('id_order_status'=>14));
            //D("Order/OrderRecord")->addHistory($order_id,$status_id,3,$comment.$_POST['comment']);
            $status = 1; $message = '';
            $update_data = array(
                'id'=>$order_id,
                'status_id'=>$status_id,
                'comment'=>$comment
            );
            UpdateStatusModel::cancel($update_data);
        }catch (\Exception $e){
            $status = 1; $message = $e->getMessage();
        }
        add_system_record(sp_get_current_admin_id(), 2, 4, '仓库取消订单');
        echo json_encode(array('status'=>$status,'message'=>$message));
    }
    
    /**
     * 导出订单列表
     */
    public function export_search() {
        vendor("PHPExcel.PHPExcel");
        vendor("PHPExcel.PHPExcel.IOFactory");
        vendor("PHPExcel.PHPExcel.Writer.CSV");
        $excel = new \PHPExcel();

        $column = array(
            '地区', '订单号', '姓名', '电话号码', '邮箱',
            '产品名和价格', '总价（NTS）', '属性',
            '送货地址', '购买产品数量', '留言备注', '下单时间', '订单状态',
            '发货日期', '运单号', '物流状态','物流名称'
        );
        $j = 65;
        foreach ($column as $col) {
            $excel->getActiveSheet()->setCellValue(chr($j) . '1', $col);
            ++$j;
        }

        $where = $this->orderModel->form_where($_GET);
        if(empty($_GET['status_id'])){
            $where['id_order_status'] = array('IN',array(4, 5, 6, 7, 8, 9, 10, 14,17));
        }
        if ($_GET['shipping_start_time'] or $_GET['shipping_end_time']) {

            $date_delivery_array = array();
            if ($_GET['shipping_start_time'])
                $date_delivery_array[] = array('EGT', $_GET['shipping_start_time']);
            if ($_GET['shipping_end_time'])
                $date_delivery_array[] = array('LT', $_GET['shipping_end_time']);
            $where['date_delivery'] = $date_delivery_array;
        }
        $orders = $this->orderModel
                ->where($where)
                ->order("id_order ASC")
            ->limit(5000)->select();
        $result = D('Order/OrderStatus')->select();
        $status = array();
        foreach ($result as $statu) {
            $status[(int) $statu['id_order_status']] = $statu;
        }
//        dump($status);die;
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        $idx = 2;
        $shipping = D('Common/Shipping')->cache(true,36000)->select();
        $shipping_data = array_column($shipping,'title','id_shipping');
        /** @var \Order\Model\OrderRecordModel  $order_record */
        $order_record = D("Order/OrderRecord");
        foreach ($orders as $o) {
            $product_name = '';
            $attrs = '';
            $products = $order_item->get_item_list($o['id_order']);
            $product_count = 0;
            foreach ($products as $p) {
                $product_name .= $p['product_title'] . "\n";
                $attrs .= $p['sku_title']. ' x ' . $p['quantity'] . ",";
                $product_count += $p['quantity'];
            }
            $attrs = trim($attrs, ',');
            $status_name = isset($status[$o['id_order_status']]) ? $status[$o['id_order_status']]['title'] : '未知';
            $getShipObj = D("Order/OrderShipping")->alias('os')->field('track_number,status_label')//,s.title as shipping_name
                                                 //->join('__SHIPPING__ as s on s.id_shipping = os.id_shipping','left')
                                                 ->where(array('id_order'=>$o['id_order']))->select();

            $trackNumber = $getShipObj ? implode(',', array_column($getShipObj, 'track_number')) : '';
            $trackStatusLabel = $getShipObj ? implode(',', array_column($getShipObj, 'status_label')) : '';
            $shipping_name = $shipping_data[$o['id_shipping']];

            $data = array(
                $o['province'], $o['id_increment'], $o['first_name'], $o['tel'], $o['email'],
                $product_name, $o['price_total'], $attrs,
                $o['address'], $product_count, $o['remark'], $o['created_at'], $status_name,
                $o['date_delivery'], $trackNumber, $trackStatusLabel, $shipping_name
            );
            $j = 65;
            foreach ($data as $key=>$col) {
                if($key != 6 && $key != 9){
                    $excel->getActiveSheet()->setCellValueExplicit(chr($j).$idx, $col);
                }else{
                    $excel->getActiveSheet()->setCellValue(chr($j) . $idx, $col);
                }
//                $excel->getActiveSheet()->setCellValue(chr($j) . $idx, $col);
                ++$j;
            }
            ++$idx;
            $order_record->addHistory($o['id_order'],$o['id_order_status'],4, '仓库管理 订单列表 导出订单');
        }
        add_system_record(sp_get_current_admin_id(), 6, 4, '导出仓库订单列表');
        $excel->getActiveSheet()->setTitle(date('Y-m-d') . '订单信息.xlsx');
        $excel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . date('Y-m-d') . '订单信息.xlsx"');
        header('Cache-Control: max-age=0');
        $writer = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $writer->save('php://output');exit();
    }


    /**
     * 分状态导出订单列表
     */
    public function export_search_status() {
        vendor("PHPExcel.PHPExcel");
        vendor("PHPExcel.PHPExcel.IOFactory");
        vendor("PHPExcel.PHPExcel.Writer.CSV");
        $excel = new \PHPExcel();

        $column = array(
            '地区', '订单号', '姓名', '电话号码', '邮箱',
            '产品名和价格', '总价（NTS）', '属性',
            '送货地址', '购买产品数量', '留言备注', '下单时间', '订单状态',
            '发货日期', '运单号', '物流状态','物流名称'
        );
        $j = 65;
        foreach ($column as $col) {
            $excel->getActiveSheet()->setCellValue(chr($j) . '1', $col);
            ++$j;
        }
        $where = $this->orderModel->form_where($_GET);

         $where['id_order_status'] = array('EQ',$_GET['status_id']);

        $orders = $this->orderModel
            ->where($where)
            ->order("id_order ASC")
            ->limit(5000)->select();
        $result = D('Order/OrderStatus')->select();
        $status = array();
        foreach ($result as $statu) {
            $status[(int) $statu['id_order_status']] = $statu;
        }
//        dump($status);die;
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        $idx = 2;
        $shipping = D('Common/Shipping')->cache(true,36000)->select();
        $shipping_data = array_column($shipping,'title','id_shipping');
        /** @var \Order\Model\OrderRecordModel  $order_record */
        $order_record = D("Order/OrderRecord");
        foreach ($orders as $o) {
            $product_name = '';
            $attrs = '';
            $products = $order_item->get_item_list($o['id_order']);
            $product_count = 0;
            foreach ($products as $p) {
                $product_name .= $p['product_title'] . "\n";
                $attrs .= $p['sku_title']. ' x ' . $p['quantity'] . ",";
                $product_count += $p['quantity'];
            }
            $attrs = trim($attrs, ',');
            $status_name = isset($status[$o['id_order_status']]) ? $status[$o['id_order_status']]['title'] : '未知';
            $getShipObj = D("Order/OrderShipping")->alias('os')->field('track_number,status_label')//,s.title as shipping_name
                //->join('__SHIPPING__ as s on s.id_shipping = os.id_shipping','left')
                ->where(array('id_order'=>$o['id_order']))->select();

            $trackNumber = $getShipObj ? implode(',', array_column($getShipObj, 'track_number')) : '';
            $trackStatusLabel = $getShipObj ? implode(',', array_column($getShipObj, 'status_label')) : '';
            $shipping_name = $shipping_data[$o['id_shipping']];

            $data = array(
                $o['province'], $o['id_increment'], $o['first_name'], $o['tel'], $o['email'],
                $product_name, $o['price_total'], $attrs,
                $o['address'], $product_count, $o['remark'], $o['created_at'], $status_name,
                $o['date_delivery'], $trackNumber, $trackStatusLabel, $shipping_name
            );
            $j = 65;
            foreach ($data as $key=>$col) {
                if($key != 6 && $key != 9){
                    $excel->getActiveSheet()->setCellValueExplicit(chr($j).$idx, $col);
                }else{
                    $excel->getActiveSheet()->setCellValue(chr($j) . $idx, $col);
                }
//                $excel->getActiveSheet()->setCellValue(chr($j) . $idx, $col);
                ++$j;
            }
            ++$idx;
            $order_record->addHistory($o['id_order'],$o['id_order_status'],4, '仓库管理 订单列表 导出订单');
        }
        add_system_record(sp_get_current_admin_id(), 6, 4, '导出仓库订单列表');
        $excel->getActiveSheet()->setTitle(date('Y-m-d') . '订单信息.xlsx');
        $excel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . date('Y-m-d') . '订单信息.xlsx"');
        header('Cache-Control: max-age=0');
        $writer = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $writer->save('php://output');exit();
    }
}
