<?php
namespace Order\Model;
use Common\Model\CommonModel;
class OrderStatusModel extends CommonModel {
    protected $_validate = array(
        //array(验证字段,验证规则,错误提示,验证条件,附加规则,验证时间)
        //array('id_department', 'require', '部门不能为空！', self::MUST_VALIDATE, 'regex', self::MODEL_BOTH),
        //array('title', 'require', '标题不能为空！', self::MUST_VALIDATE, 'regex', self::MODEL_BOTH),
        //array('model', 'require', 'SKU不能为空！', self::MUST_VALIDATE, 'regex', self::MODEL_BOTH),
    );
	protected function _before_write(&$data) {
		parent::_before_write($data);
	}
    public function page($total_size = 1, $page_size = 0, $current_page = 1, $listRows = 6, $pageParam = '', $pageLink = '', $static = FALSE){
        if ($page_size == 0) {
            $page_size = C("PAGE_LISTROWS");
        }
        if (empty($pageParam)) {
            $pageParam = C("VAR_PAGE");
        }
        $Page = new \Page($total_size, $page_size, $current_page, $listRows, $pageParam, $pageLink, $static);
        $Page->SetPager('Admin', '{first}{prev}&nbsp;{liststart}{list}{listend}&nbsp;{next}{last}', array("listlong" => "9", "first" => "首页", "last" => "尾页", "prev" => "上一页", "next" => "下一页", "list" => "*", "disabledclass" => ""));
        return $Page;
    }
    /**
     * 获取状态
     * @param bool $status_id
     * @return array
     */
    public function get_status_label($status_id=false){
        $list = D("Order/OrderStatus")->field('id_order_status,title')->where('status=1')->cache(true,13600)->select();
        $array = array_column($list,'title','id_order_status');
        return $status_id?$array[$status_id]:$array;
    }
    /**
     * 获取用户对应的订单列表
     * @param bool $set_where
     * @return array
     */
    public function get_untreated_order_byusers($set_where=false,$is_tf=false,$admin_id =""){
        /** @var \Order\Model\OrderModel $order_model */
        $order_model = D("Order/Order");
        $where       = $order_model->form_where($_GET);
        $department_id = isset($_SESSION['department_id'])?$_SESSION['department_id']:array(0);
        $admin_id = $_SESSION['ADMIN_ID'];
        $where['id_department'] = isset($_GET['id_department']) && $_GET['id_department'] != ''?array('EQ',$_GET['id_department']):array('IN',$department_id);
        if(isset($_GET['id_department']) && $_GET['id_department']){
            $where['id_department']= $_GET['id_department'];
        }
        
        if($is_tf == false){
            $where['_string'] = "(payment_method is NULL OR payment_method='' or payment_method='0')";//货到付款订单，过滤已经支付的
        }
        $where['id_order_status'] = isset($set_where['id_order_status'])?$set_where['id_order_status']:array('EQ',1);
        $where['id_users'] = $admin_id;

        //过滤产品
        if($_GET['id_product']){
            $M = new \Think\Model;
            $ord_name = D("Common/Order")->getTableName();
            $ord_ite_name = D("Common/OrderItem")->getTableName();
            $user_name = D("Common/Users")->getTableName();
            $product_where = array('oi.id_product'=>$_GET['id_product'],
                'o.id_department'=>array('IN',$department_id),
                'o.id_order_status'=>$where['id_order_status'],
                'o.id_users'=>array('EQ',$admin_id)
            );
            $find_order = $M->table($ord_name.' AS o LEFT JOIN '.$ord_ite_name.' AS oi ON o.id_order=oi.id_order')->field('o.id_order')
                ->where($product_where)
                ->group('oi.id_order')->select();
            $all_id = array_column($find_order,'id_order');

            $where['id_order'] = $all_id?array('IN',$all_id):array('IN',array(0));
        }
        if($set_where){
            $where = array_merge($where,$set_where);
        }
        $count = $order_model->where($where)->count();
        $today_where = $where;
        $today_where['SUBSTRING(created_at,1,10)'] = date('Y-m-d');
        $today_total  = $order_model->where($today_where)->count();
        $form_data  = array();
        $all_domain = D('Common/Domain')
            ->field('`name`,id_domain')->where(array('id_department'=>array('IN',$department_id)))
            ->order('`name` ASC')
            ->select();
        $form_data['domain'] = $all_domain?array_column($all_domain,'name','id_domain'):array();


        $page = $this->page($count, 20);
        $order_list = $order_model->where($where)->order("id_order desc,tel DESC,`first_name` desc,email desc")
            ->limit($page->firstRow . ',' . $page->listRows)
            ->select();

        /** @var \Order\Model\OrderBlacklistModel $order_blacklist */
        $order_blacklist = D("Order/OrderBlacklist");
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        foreach ($order_list as $key => $o) {
            $order_list[$key]  =  $order_blacklist->black_list_and_ip_address($o);
            $order_list[$key]['products'] = $order_item->get_item_list($o['id_order']);
            $order_list[$key]['total_price'] = \Common\Lib\Currency::format($o['price_total'],$o['currency_code']);
        }
        $all_product = D('Product/Product')
            ->field('id_product,title')->where(array('id_department'=>array('IN',$department_id)))
            ->order('id_product desc')->cache(true,86400)->select();

        //echo $baseSql->where($where)->fetchSql(true)->select();
        $shipping = D("Common/Shipping")->where('status=1')->cache(true,6000)->select();
        $all_zone = D('Common/Zone')->field('`title`,id_zone')->order('`title` ASC')->cache(true, 3600)->select();
        $form_data['zone'] = $all_domain?array_column($all_zone,'title','id_zone'):'';
        /*$form_data['track_status'] = D('Order/OrderShipping')->field('status_label as track_status')
            ->where("status_label is not null or status_label !='' ")
            ->group('status_label')->cache(true, 22000)->select();*/
        $advertiser = D('Common/Users')->field('id,user_nicename as name')->cache(true,36000)->select();
        $advertiser = array_column($advertiser,'name','id');
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        return array(
            'form_data'   => $form_data,
            'page'        => $page->show('Admin'),
            'today_total' => $today_total,
            'order_total' => $count,
            'order_list'  => $order_list,
            'shipping'    => $shipping,
            'all_product' => $all_product,
            'advertiser'  => $advertiser,
            'all_zone'    => $all_zone,
        );
    }
    /**
     * 获取订单列表
     * @param bool $set_where
     * @return array
     */
    public function get_untreated_order($set_where=false,$is_tf=false){
        /** @var \Order\Model\OrderModel $order_model */
        $order_model = D("Order/Order");
        $where       = $order_model->form_where($_GET);
        $department_id = isset($_SESSION['department_id'])?$_SESSION['department_id']:array(0);
        $where['id_department'] = isset($_GET['id_department']) && $_GET['id_department'] != ''?array('EQ',$_GET['id_department']):array('IN',$department_id);
        if(isset($_GET['id_department']) && $_GET['id_department']){
            $where['id_department']= $_GET['id_department'];
        }

        if($is_tf == false){
            $where['_string'] = "(payment_method is NULL OR payment_method='' or payment_method='0')";//货到付款订单，过滤已经支付的
        }
        $where['id_order_status'] = isset($set_where['id_order_status'])?$set_where['id_order_status']:array('EQ',1);

        //过滤产品
        if($_GET['id_product']){
            $M = new \Think\Model;
            $ord_name = D("Common/Order")->getTableName();
            $ord_ite_name = D("Common/OrderItem")->getTableName();
            $product_where = array('oi.id_product'=>$_GET['id_product'],
                'o.id_department'=>array('IN',$department_id),
                'o.id_order_status'=>$where['id_order_status']
            );
            $find_order = $M->table($ord_name.' AS o LEFT JOIN '.$ord_ite_name.' AS oi ON o.id_order=oi.id_order')->field('o.id_order')
                ->where($product_where)
                ->group('oi.id_order')->select();
            $all_id = array_column($find_order,'id_order');
            $where['id_order'] = $all_id?array('IN',$all_id):array('IN',array(0));
        }
        if($set_where){
            $where = array_merge($where,$set_where);
        }
        $count = $order_model->where($where)->count();
        $today_where = $where;
        $today_where['SUBSTRING(created_at,1,10)'] = date('Y-m-d');
        $today_total  = $order_model->where($today_where)->count();
        $form_data  = array();
        $all_domain = D('Common/Domain')
            ->field('`name`,id_domain')->where(array('id_department'=>array('IN',$department_id)))
            ->order('`name` ASC')
            ->select();
        $form_data['domain'] = $all_domain?array_column($all_domain,'name','id_domain'):array();


        $page = $this->page($count, 20);
        $order_list = $order_model->where($where)->order("id_order desc,tel DESC,`first_name` desc,email desc")
            ->limit($page->firstRow . ',' . $page->listRows)
            ->select();

        /** @var \Order\Model\OrderBlacklistModel $order_blacklist */
        $order_blacklist = D("Order/OrderBlacklist");
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        foreach ($order_list as $key => $o) {
            $order_list[$key]  =  $order_blacklist->black_list_and_ip_address($o);
            $order_list[$key]['products'] = $order_item->get_item_list($o['id_order'],10);
            $order_list[$key]['total_price'] = \Common\Lib\Currency::format($o['price_total'],$o['currency_code']);
        }
        $all_product = D('Product/Product')
            ->field('id_product,title')->where(array('id_department'=>array('IN',$department_id)))
            ->order('id_product desc')->cache(true,86400)->select();

        //echo $baseSql->where($where)->fetchSql(true)->select();
        $shipping = D("Common/Shipping")->where('status=1')->cache(true,6000)->select();
        $all_zone = D('Common/Zone')->field('`title`,id_zone')->order('`title` ASC')->cache(true, 3600)->select();
        $form_data['zone'] = $all_domain?array_column($all_zone,'title','id_zone'):'';
        /*$form_data['track_status'] = D('Order/OrderShipping')->field('status_label as track_status')
            ->where("status_label is not null or status_label !='' ")
            ->group('status_label')->cache(true, 22000)->select();*/
        $advertiser = D('Common/Users')->field('id,user_nicename as name')->cache(true,36000)->select();
        $advertiser = array_column($advertiser,'name','id');
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        return array(
            'form_data'   => $form_data,
            'page'        => $page->show('Admin'),
            'today_total' => $today_total,
            'order_total' => $count,
            'order_list'  => $order_list,
            'shipping'    => $shipping,
            'all_product' => $all_product,
            'advertiser'  => $advertiser,
            'all_zone'  => $all_zone,
        );
    }
    /**
     * 未处理审核后的订单
     * @param $order_id
     * @param $statusId
     * @param bool $comment
     * @return int
     */
    public function approved($order_id, $status_id, $comment = false){
        $order = D("Order/Order")->find($order_id);
        //2为待发货状态记录，7为无效订单，订单表记录为无效订单，order History记录无效订单的原因
        $update_data = array('id_order_status' => $status_id);
        $_POST['delivery_date'] = strtotime($_POST['delivery_date'])>strtotime($order['create_at'])?$_POST['delivery_date']:$order['create_at'];
        if (isset($_POST['delivery_date']) && $_POST['delivery_date']) {
            $update_data['delivery_date'] = $_POST['delivery_date'];
        } else {
            $update_data['delivery_date'] = strtotime($order['create_at'])>0?$order['create_at']:date('Y-m-d 10:00:00',strtotime('-1 day'));//$order['create_at'] ? $order['create_at'] : date('Y-m-d');
        }
        //备注订单信息
        $update_data['comment'] = $comment;
        $result = D("Common/Order")->where(array('id_order'=>$order['id_order']))->save($update_data);
        if($result){
            /** @var \Order\Model\OrderRecordModel  $order_record */
            $order_record = D("Order/OrderRecord");
            $order_record->addHistory($order['id_order'],$status_id, $comment);
        }
        $return = 1;
        return $return;
    }
    /**
     * 更新订单状态，并且记录更新信息
     * @param $data
     */
    public function update_status_add_history($data){
        if($data['id_order']  && $data['new_status_id']){
            $update_data = array('id_order_status'=>$data['new_status_id'],'date_delivery'=>date('Y-m-d H:i:s'));
            $result = D("Order/Order")->where(array('id_order'=>$data['id_order']))->save($update_data);
//            if($result){
                /** @var \Order\Model\OrderRecordModel  $order_record */
                $order_record = D("Order/OrderRecord");
                $comment      = $data['comment']?:'';
                $order_record->addHistory($data['id_order'],$data['new_status_id'],4, $comment);
//            }
        }
    }
}