<?php

namespace Order\Controller;

use Common\Controller\AdminbaseController;

/**
 * 订单管理模块
 * @Author morrowind
 * @qq 752979972
 * Class IndexController
 * @package Order\Controller
 */
class IndexController extends AdminbaseController {

    protected $order,$page;

    public function _initialize() {
        parent::_initialize();
        $this->order = D("Order/Order");
        $this->page      = $_SESSION['set_page_row']?(int)$_SESSION['set_page_row']:20;
    }

    /**
     * 订单列表
     */
    public function index() {
        /** @var \Order\Model\OrderModel $order_model */
        $order_model = $this->order;
        $where = $order_model->form_where($_GET,'o.');
        $department_id = isset($_SESSION['department_id'])?$_SESSION['department_id']:array(0);
        $where['id_department'] = isset($_GET['id_department']) && $_GET['id_department'] != ''?array('EQ',$_GET['id_department']):array('IN',$department_id);
        if(isset($_GET['id_department']) && $_GET['id_department']){
            $where['id_department']= $_GET['id_department'];
        }
        
        $where['_string'] = "(o.payment_method is NULL OR o.payment_method='' or o.payment_method='0')";//货到付款订单，过滤已经支付的
        $today_date = date('Y-m-d 00:00:00');
        $form_data = array();
        /** @var \Domain\Model\DomainModel $domain_model */
        $domain_model = D('Domain/Domain');
        $form_data['domain'] = $domain_model->get_all_domain();

        //$formData['product_type'] = $baseSql->getFieldGroupData('product_type');
        $form_data['track_status'] = D('Order/OrderShipping')->field('status_label as track_status')
                        ->where("status_label is not null or status_label !='' ")
                        ->group('status_label')->cache(true, 12000)->select();


        //今日统计订单 条件
        $today_where = $where;
        $today_where['o.created_at'] = array('EGT', $today_date);
        $all_domain_total = $order_model->alias('o')->field('count(`id_domain`) as total,id_domain')->where($today_where)
                        ->order('total desc')->group('id_domain')->select();

        //修改过滤物流状态， 当不需要过滤物流状态时，很卡，所以需要判断是否需要过滤物流状态
        if (isset($_GET['status_label']) && $_GET['status_label']) {
            $where['s.status_label'] = strip_tags(trim($_GET['status_label']));
            $count = $order_model->alias('o')
                            ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.id_order)', 'LEFT')
                            ->where($where)->count();
            $today_total = $order_model->alias('o')
                            ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.id_order)', 'LEFT')
                            ->where($today_where)->count();
            $page = $this->page($count, $this->page);
            $order_list = $order_model->alias('o')->field('o.*,s.date_signed,oi.ip as ip')
                            ->join('__ORDER_SHIPPING__ s ON (o.id_order = s.id_order)', 'LEFT')
                            ->join('__ORDER_INFO__ oi ON (o.id_order = oi.id_order)', 'LEFT')
                            ->where($where)->order("id_order DESC")->limit($page->firstRow . ',' . $page->listRows)->select();
        } else {
            $count = $order_model->alias('o')->where($where)->count();
            $today_total = $order_model->alias('o')->where($today_where)->count();
            $page = $this->page($count, $this->page);
            $order_list = $order_model->alias('o')->field('o.*,oi.ip as ip')->join('__ORDER_INFO__ oi ON (o.id_order = oi.id_order)', 'LEFT')->where($where)->order("id_order DESC")->limit($page->firstRow . ',' . $page->listRows)->select();
        }
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        foreach ($order_list as $key => $o) {
            $order_list[$key]['products'] = $order_item->get_item_list($o['id_order']);
            $order_list[$key]['total_price'] = \Common\Lib\Currency::format($o['price_total'],$o['currency_code']);
        }
        $advertiser = D('Common/Users')->field('id,user_nicename as name')->cache(true,36000)->select();
        $advertiser = array_column($advertiser,'name','id');
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        add_system_record($_SESSION['ADMIN_ID'], 4, 4,'查看DF订单列表');
        /** @var \Common\Model\ZoneModel $zone_model */
        $zone_model = D('Common/Zone');
        $all_zone = $zone_model->all_zone();
        $this->assign("all_zone", $all_zone);
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $advertiser);
        $this->assign("get", $_GET);
        $this->assign("form_data", $form_data);
        $this->assign("page", $page->show('Admin'));
        $this->assign("today_total", $today_total);
        $this->assign("order_total", $count);
        $this->assign("all_domain_total", $all_domain_total);

        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("order_list", $order_list);
        $this->display();
    }

    /**
     * 导出订单列表
     */
    public function export_search() {
        vendor("PHPExcel.PHPExcel");
        vendor("PHPExcel.PHPExcel.IOFactory");
        vendor("PHPExcel.PHPExcel.Writer.CSV");
        $excel = new \PHPExcel();

        $column = array(
            '地区', '域名', '订单号', '姓名', '电话号码', '邮箱',
            '产品名和价格', '总价（NTS）', '属性',
            '送货地址', '购买产品数量', '留言备注', '下单时间', '订单状态',
            '发货日期', '运单号', '物流状态'
        );
        $j = 65;
        foreach ($column as $col) {
            $excel->getActiveSheet()->setCellValue(chr($j) . '1', $col);
            ++$j;
        }
        $where = $this->order->form_where($_GET);
        $where['_string'] = "(payment_method is NULL OR payment_method='' or payment_method='0')";//货到付款订单，过滤已经支付的
        $department_id = isset($_SESSION['department_id'])?$_SESSION['department_id']:array(0);
        $where['id_department'] = isset($_GET['id_department']) && $_GET['id_department'] != ''?array('EQ',$_GET['id_department']):array('IN',$department_id);
        if(isset($_GET['id_department']) && $_GET['id_department']){
            $where['id_department']= $_GET['id_department'];
        }
        $orders = $this->order
                ->where($where)
                ->order("id_order ASC")
            ->limit(10000)->select();
        $result = D('Order/OrderStatus')->select();
        $status = array();
        foreach ($result as $statu) {
            $status[(int) $statu['id_order_status']] = $statu;
        }
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        $idx = 2;
        foreach ($orders as $o) {
            $product_name = '';
            $attrs = '';
            $products = $order_item->get_item_list($o['id_order']);
            $product_count = 0;
            foreach ($products as $p) {
                $product_name .= $p['product_title'] . "\n";
                if($p['sku_title']) {
                    $attrs .= $p['sku_title']. ' x ' . $p['quantity'] . ",";
                } else {
                    $attrs .= $p['product_title']. ' x ' . $p['quantity'] . ",";
                }
                $product_count +=$p['quantity'];
            }
            $attrs = trim($attrs, ',');
            $status_name = isset($status[$o['id_order_status']]) ? $status[$o['id_order_status']]['title'] : '未知';
            $domain_title = D('Domain/Domain')->where(array('id_domain'=>$o['id_domain']))->getField('name');
            $getShipObj = D("Order/OrderShipping")->field('track_number,status_label')->where('id_order=' . $o['id_order'])->select();
            $trackNumber = $getShipObj ? implode(',', array_column($getShipObj, 'track_number')) : '';
            $trackStatusLabel = $getShipObj ? implode(',', array_column($getShipObj, 'status_label')) : '';
            $data = array(
                $o['province'], $domain_title, $o['id_increment'], $o['first_name'], $o['tel'], $o['email'],
                $product_name, $o['price_total'], $attrs,
                $o['address'], $product_count, $o['remark'], $o['created_at'], $status_name,
                $o['date_delivery'], $trackNumber, $trackStatusLabel
            );
            $j = 65;
            foreach ($data as $key=>$col) {
                if($key != 7 && $key != 10) {
                    $excel->getActiveSheet()->setCellValueExplicit(chr($j).$idx, $col);
                } else {
                    $excel->getActiveSheet()->setCellValue(chr($j) . $idx, $col);
                }
                ++$j;
            }
            ++$idx;
        }
        add_system_record(sp_get_current_admin_id(), 7, 4, '导出DF订单列表');
        $excel->getActiveSheet()->setTitle(date('Y-m-d') . '订单信息.xlsx');
        $excel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . date('Y-m-d') . '订单信息.xlsx"');
        header('Cache-Control: max-age=0');
        $writer = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $writer->save('php://output');exit();
    }

    /**
     * 订单详情
     */
    public function info(){
        $order_id = I('get.id');
        $order = D("Order/Order")->find($order_id);
        $statusLabel = D("Order/OrderStatus")->get_status_label();
        $orderHistory = D("Order/OrderRecord")
            ->field('*')
            ->join('__USERS__ u ON (__ORDER_RECORD__.id_users = u.id)', 'LEFT')
            ->where(array('id_order'=>$order_id))
            ->order('created_at desc')->select();
        $shipping = D('Common/Shipping')
            ->where(array('id_shipping'=>(int)$order['id_shipping']))->cache(true,3600)
            ->find();
        /** @var \Domain\Model\DomainModel $domain_model */
        $domain_model = D('Domain/Domain');
        $all_domain = $domain_model->get_all_domain();
        $order['id_domain'] = $all_domain[$order['id_domain']];
        $order['id_order_status'] = $statusLabel[$order['id_order_status']];
        $products = D('Order/OrderItem')->get_item_list($order['id_order']);
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看DF订单详情');
        $this->assign("order", $order);
        $this->assign("products", $products);
        $this->assign("history", $orderHistory);
        $this->assign("label", $statusLabel);
        $this->assign('shipping_name', $shipping['title']);
        $this->assign('shopping_url', $shipping['track_url']);
        $this->display();
    }
    /**
     * 编辑订单 from表单
     */
    public function edit_order() {
        $getId = I('get.id/i');
        $department_id = isset($_SESSION['department_id']) ? $_SESSION['department_id'] : array(0);
        $where = array('id_order' => array('EQ', $getId));
        $where['id_department'] = array('IN', $department_id);
        $order = $this->order->where($where)->find();
        if(!$order){
            $this->error("你没有权限操作此订单！");
        }
        /** @var \Common\Model\ProductModel $product */
        $product = D('Common/Product');
        $order_item = D('Order/OrderItem');
        $products = $order_item->where(array(
                    'id_order' => $order['id_order']
                ))->order('id_product desc')->select();
        /** @var  $options \Product\Model\ProductOptionModel */
        $options = D('Product/ProductOption');
        $all_attr = array();
        $arr_html = array();
        
        if ($products) {
            foreach ($products as $key => $product) {                
                $product_id = $product['id_product'];
                if(!empty($product_id)) {
                    $sku_id = $product['id_product_sku'];
                    $arr_html[$product_id]['id_product'] = $product_id;
                    $arr_html[$product_id]['product_title'] = $product['product_title'];
                    $arr_html[$product_id]['id_order_item'] = $product['id_order_item'];
                    $arr_html[$product_id]['id_order_items'][$sku_id] = $product['id_order_item'];
                    $arr_html[$product_id]['quantity'][$sku_id] = $product['quantity'];
                    $arr_html[$product_id]['attrs'][$sku_id] = unserialize($product['attrs']);
                    $arr_html[$product_id]['attr_option_value'][$sku_id] = $options->get_attr_list_by_id($product_id);
                    $arr_html[$product_id]['attr_option_value_data'] = $options->get_attr_list_by_id($product_id);
                    $arr_html[$product_id]['sku_id'] = $product['id_product_sku'];
                    $products[$key]['attr_option_value'] = $all_attr[$product_id] ? $all_attr[$product_id] : $options->get_attr_list_by_id($product_id);
                    $all_attr[$product_id][$sku_id] = $all_attr[$product_id] ? $all_attr[$product_id] : $options->get_attr_list_by_id($product_id);
                }
            }
        }
        
        $this->assign("products", $arr_html);
        $this->assign("all_attr", $all_attr);
        $this->assign("order", $order);
        $this->display();
    }
    
    //编辑订单添加产品属性
    public function get_attr_html() {
        if(IS_AJAX) {
            $pro_id = I('post.id');
            $order_id = I('post.order_id');
            
            $order_item = D('Order/OrderItem');
            $products = $order_item->where(array(
                        'id_order' => $order_id
                    ))->order('id_product desc')->select();
            $options = D('Product/ProductOption');
            $all_attr = array();
            $select_attr = array();
            $select_num = array();
            
            if ($products) {
                foreach ($products as $key => $product) {                
                    $product_id = $product['id_product'];
                    if(!empty($product_id)) {
                        $sku_id = $product['id_product_sku'];
                        $select_attr[$product_id]['attrs'] = unserialize($product['attrs']);
                        $select_attr[$product_id]['quantity'] = $product['quantity'];
                        $all_attr[$product_id] = $all_attr[$product_id] ? $all_attr[$product_id] : $options->get_attr_list_by_id($product_id);
                    }
                }
            }
            
//            dump($select_attr);
            
            $html = '<tr class="productAttrRow'.$pro_id.'">';
            $html .= '<td>';
            foreach ($all_attr[$pro_id] as $k=>$val) {
                $html .= $val['title'].'&nbsp';
                $html .= '<select name="option_id['.$pro_id.']['.$val["id_product_option"].'][]">';
                foreach($val["option_values"] as $kk => $vv) {
                    $selected = in_array($vv['id_product_option_value'],$select_attr[$pro_id]['attrs']) ? 'selected' : '';  
                    $html .= '<option value ="'.$vv['id_product_option_value'].'" '.$selected.'>'.$vv['title'].'</option>';
                }
                $html .= '</select>&nbsp;&nbsp;&nbsp;';                    
            }
            $html .= '<input name="number['.$pro_id.'][]" value="'.$select_attr[$pro_id]['quantity'][0].'" type="text">&nbsp;&nbsp;';
            $html .= '<a href="javascript:void(1);" class="deleteOrderAttr" pro_id="'.$pro_id.'">删除</a>';
            $html .= '</td>';
            $html .= '</tr>';
            echo $html;die();
        }
    }

    public function edit_order_post1() {
        if (isset($_POST['action']) && $_POST['action'] == 'delete_attr') {
            //因为要添加权限，所以先写到这个控制器了。
            $orderId = I('get.id');
            $itemId = I('post.order_attr_id');
            if ($orderId && $itemId) {
                $order = D("Order/Order")->find($orderId);
                $deleteData = D("Order/OrderItem")->find($itemId);
                $comment = '删除产品属性：' . json_encode($deleteData);
//                D("Common/OrderItemOption")->where('order_item_id=' . $itemId)->delete();
                D("Order/OrderItem")->where('id_order_item=' . $itemId)->delete();
                D("Order/OrderRecord")->addHistory($orderId, $order['id_order_status'],3, $comment);
            }
            exit();
        }
        if (IS_POST) {
            $data = I('post.');
            $fp = fopen('d:a.txt', 'a+b');
            fwrite($fp, print_r($data, true));
            fclose($fp);
            $order_info = $data;
            $order_info['id'] = $data['order_id'];
            $orderId = $data['order_id'];
            unset($order_info['product_ids'], $order_info['option_id'], $order_info['number'], $order_info['attach_id'], $order_info['number_attach'], $order_info['user_remark'], $order_info['action'], $order_info['order_id']);

            $result = D('Common/Order')->save($order_info);

            $product_ids = $data['product_ids'];
            $option_id = $data['option_id'];
            $number = $data['number'];
            //TODO:每一个属性组合都是一个订单产品
            //如果添加了3个属性组合, 那么就是3个订单的产品
            //要在order_item里添加3个产品
            //并且修改订单信息, 价格等

            foreach ($product_ids as $p_id) {//循环产品
                if (!isset($option_id[$p_id]) || !isset($number[$p_id])) {
                    if (isset($data['qty'][$p_id])) {
                        D('Common/OrderItem')->where('order_id=' . $orderId . ' and product_id=' . $p_id)->save(array('qty' => $data['qty'][$p_id]));
                    }
                    continue;
                }
                //1.找到订单里产品原有的信息
                //2.删除原有的属性 in order_item_option
                //3.重新写入替代的产品属性
                /* $order_item = D('Common/OrderItem')
                  ->where(array(
                  'order_id' => $data['order_id'],
                  'product_id' => $p_id
                  ))
                  ->find(); */

                $order_option = array();
                $numbers = implode('_', array_keys($option_id[$p_id]));
                $numbers = $number[$p_id][$numbers];
                foreach ($option_id[$p_id] as $op_id => $op) {//属性集
                    //print_r($op);
                    foreach ($op as $op_key => $op_value) {
                        //$order_option里每一个数组都是一个产品属性组合
                        //$op_key相当于order_item_option里的group_id
                        /* if ($numbers[$op_key] <= 0) {
                          continue;
                          } */ //下错型号了，需要把某个型号数量修改为0 ，另外型号修改为购买数量， 所以这里需要去掉
                        $order_option[$op_key][$op_id] = array(
                            'value_id' => $op_value,
                            'number' => $numbers[$op_key]
                        );
                    }
                }

                /* D('Common/OrderItemOption')
                  ->where(array(
                  'order_item_id' => $order_item['id'],
                  'product_id' => $order_item['product_id'],
                  ))
                  ->delete(); */
                //写入新属性
                //$op_key2组编号group_id
                $buyTotalQty = 0;
                foreach ($order_option as $op_key2 => $op2) {
                    $values = array_column($op2, 'value_id');
                    sort($values);
                    $valueString = "'" . implode(',', $values) . "'";
                    $productId = $p_id;
                    $productBundle = D('Common/ProductBundle')->where('product_id=' . $productId)->cache(true, 86400)->find();
                    $parentProductId = $productBundle ? $productBundle['parent_product_id'] : 0;

                    $getSkuSelect = D('Common/ProductSku')->where('product_id=' . $productId . ' and option_value=' . $valueString)
                                    ->cache(true, 86400)->find();
                    $orItWhere = array('order_id' => $orderId, 'product_id' => $productId, 'sku_id' => $getSkuSelect['id']);
                    $getOrderItem = D('Common/OrderItem')->where($orItWhere)->find();
                    foreach ($op2 as $op3) {
                        $qty = $op3['number'];
                        break;
                    }
                    if ($getOrderItem) {
                        if ($qty == 0) {
                            //下错型号了，需要把某个型号数量修改为 0 ,清除此产品 否则更新
                            D('Common/OrderItemOption')->where('order_item_id=' . $getOrderItem['id'])->delete();
                            D('Common/OrderItem')->where('id=' . $getOrderItem['id'])->delete();
                        } else {//更新购买的库存
                            $selOrdIteOpt = D('Common/OrderItemOption')->where('order_item_id=' . $getOrderItem['id'])->select();
                            if (!$selOrdIteOpt && $values) {
                                //当没提交订单过滤，没有添加属性的时候，添加属性
                                $attrs = serialize($values);
                                D('Common/OrderItem')->where('id=' . $getOrderItem['id'] . ' and order_id=' . $orderId)
                                        ->save(array('qty' => $qty, 'attrs' => $attrs, 'sku_id' => $getSkuSelect['id']));
                                foreach ($values as $optId) {
                                    $valueLabel = D('Common/ProductOptionValue')->find($optId);
                                    $addOptData = array('order_item_id' => $getOrderItem['id'],
                                        'product_id' => $productId,
                                        'option_id' => $optId,
                                        'value_label' => $valueLabel['title'],
                                        'number' => $qty);
                                    D('Common/OrderItemOption')->data($addOptData)->add();
                                }
                            } else {
                                D('Common/OrderItem')->where('id=' . $getOrderItem['id'] . ' and order_id=' . $orderId)->save(array('qty' => $qty));
                            }
                            //D('Common/OrderItem')->where('id='.$getOrderItem['id'].' and order_id='.$orderId)->save(array('qty'=>$qty));
                            $buyTotalQty += $qty;
                        }
                        $updateLog[] = '更新 (sku_id:' . $getOrderItem['sku_id'] . ') qty(' . $getOrderItem['qty'] . ') 到' . $qty;
                    } else if ($qty > 0 && !$getOrderItem) {
                        //没有找到此记录，往订单产品表添加产品。
                        $loadProduct = D('Common/Product')->cache(true, 86400)->find($productId);
                        $total = $loadProduct['special_price'] * $qty;
                        $attrs = serialize($values);
                        $itemData = array('order_id' => $orderId, 'product_id' => $productId,
                            'product_title' => $loadProduct['title'],
                            'sku_id' => $getSkuSelect['id'], 'attrs' => $attrs, 'qty' => $qty,
                            'price' => $loadProduct['special_price'], 'total' => $total);
                        $itemData['parent_prodct_id'] = $parentProductId;
                        $getItemId = D('Common/OrderItem')->data($itemData)->add();
                        foreach ($values as $valId) {
                            $getOptVal = D('Common/ProductOptionValue')->cache(true, 86400)->find($valId);
                            $itemVal = array('order_item_id' => $getItemId, 'product_id' => $productId,
                                'option_id' => $valId, 'value_label' => $getOptVal['title']);
                            D('Common/OrderItemOption')->data($itemVal)->add();
                        }
                        $buyTotalQty += $qty;
                        $updateLog[] = '新添加 (sku_id:' . $getSkuSelect['id'] . ') qty (' . $qty['qty'] . ') 到订单';
                    }
                }
            }
            $remark = $updateLog ? implode(',', $updateLog) : '';
            D("Common/OrderStatusHistory")->addHistory($orderId, 1, $remark);
            if (isset($data['attach_id'])) {
                $attachId = $data['attach_id'];
                $numberAttach = $data['number_attach'];
                foreach ($attachId as $key => $atId) {
                    if ($numberAttach[$key] > 0) {
                        $qty = $numberAttach[$key];
                        $loadProduct = D('Common/Product')->cache(true, 86400)->find($atId);
                        $total = $loadProduct['special_price'] * $qty;
                        $itemData = array('order_id' => $orderId, 'product_id' => $atId,
                            'product_title' => $loadProduct['title'],
                            'sku_id' => '', 'attrs' => '', 'qty' => $qty,
                            'price' => $loadProduct['special_price'], 'total' => $total);
                        $getItemId = D('Common/OrderItem')->data($itemData)->add();
                        $buyTotalQty += $qty;
                    }
                }
            }
            $updateData = array(
                'id' => $orderId,
            );
            Hook::run('event:order:status:update', $updateData, 'editOrder');
            //D('Common/Order')->where('id='.$orderId)->save(array('total_qty_ordered'=>$buyTotalQty));
            $this->success("保存完成！", U('Order/editorder', array('id' => $orderId)));
        } else {
            $this->error("参数不正确！");
        }
    }

    /**
     * 处理编辑订单
     */
    public function edit_order_post() {
        $orderId = I('get.id');
        $order = D("Order/Order")->find($orderId);
        if (isset($_POST['action']) && $_POST['action'] == 'delete_attr') {
            //因为要添加权限，所以先写到这个控制器了。            
            $itemId = I('post.order_attr_id');
            if ($orderId && $itemId) {
                $deleteData = D("Order/OrderItem")->find($itemId);
                $comment = '删除产品属性：' . json_encode($deleteData);
                D("Order/OrderItem")->where('id_order_item=' . $itemId)->delete();
//                D('Order/Order')->where('id_order='.$orderId)->save(array('price_total'=>$order['price_total']-$deleteData['total']));
                D("Order/OrderRecord")->addHistory($orderId, $order['id_order_status'],3, $comment);
            }
            F('order_item_by_order_id_cache'.$orderId,null);
            exit();
        }
        
        if(IS_POST) {
            $data = I('post.'); 
//            dump($data['number']);die;
            D('Order/Order')->save($data);
            
            $product_id = array();
            foreach($data['option_id'] as $key=>$val){
                $product_id[] = $key;
                $temp = array();

                foreach($val as $k=>$v) {
                    foreach($v as $kk=>$vv){
                        $temp[$kk][] = $vv;                        
                    }                    
                }
                $product = D('Product/Product')->field('title,inner_name,sale_price')->where('id_product='.$key)->find();
                foreach($temp as $psk =>$psv)  { 
                    
                    $option_value = asort($psv);
                    $option_value = implode(',', $psv);
                    $product_sku = D('Product/ProductSku')->where("option_value='$option_value' and id_product=$key")->find();
                    $item_result = D('Order/OrderItem')->where('id_product='.$key.' and id_product_sku='.$product_sku['id_product_sku'].' and id_order='.$data['id_order'])->find();                                      
                    $item_data['id_order'] = $data['id_order'];
                    $item_data['id_product'] = $key;
                    $item_data['id_product_sku'] = $product_sku['id_product_sku']; 
                    $item_data['sku'] = $product_sku['sku'];
                    $item_data['sku_title'] = $product_sku['title'];
                    $item_data['sale_title'] = $product['title'];
                    $item_data['product_title'] = $product['title'];
                    $item_data['quantity'] = $data['number'][$key][$psk];
                    $item_data['price'] = $product['sale_price'];
                    $item_data['total'] = $product['sale_price']*$data['number'][$key][$psk];
                    $item_data['attrs'] = serialize($psv);
                    if(array_keys($data['order_item_id'][$key])[$psk] == $psk) {
                        D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$key][$psk])->data($item_data)->save();
                    } else {
                        if($product_sku['id_product_sku'] == $item_result['id_product_sku'] || empty($data['number'][$key][$psk])) continue;
                        D('Order/OrderItem')->data($item_data)->add();
                    }                    
                    if($data['number'][$key][$psk] == 0) {
                        D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$key][$psk])->delete();
                    }
                }
            } 

            foreach ($data['pro_id'] as $pro_key=>$pro_val) {
                if(!in_array($pro_val,$product_id)) {
                    $other_product = D('Product/Product')->field('title,inner_name,sale_price')->where('id_product='.$pro_val)->find();
                    $item_id = $data['order_item_id'][$pro_val][0];
                    $other_item_data['total'] = $other_product['sale_price']*$data['qty'.$pro_val];
                    $other_item_data['quantity'] = $data['qty'.$pro_val];
                    D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$pro_val][0])->data($other_item_data)->save();
                }

                if(isset($data['qty'.$pro_val]) && $data['qty'.$pro_val] == 0) {
                    D('Order/OrderItem')->where('id_order_item='.$data['order_item_id'][$pro_val][0])->delete();
                }
            }      
            D("Order/OrderRecord")->addHistory($orderId, $order['id_order_status'],2, '编辑订单属性');
            add_system_record(sp_get_current_admin_id(), 2, 4, '编辑DF订单属性');
            F('order_item_by_order_id_cache'.$orderId,null);
            $this->success("保存完成！", U('Index/edit_order', array('id' => $orderId)));
        } else {
            $this->error("参数不正确！");
        }
    }

    /**
     * 单个填写物流跟踪号发货，修改订单状态为发货
     */
    public function delivery() {
        $orderId = (int) $_POST['order_id'];
        if ($_POST['track_number'] && $orderId) {
            $getTrackNumber = explode(',', str_replace('，', ',', $_POST['track_number']));
            $trackNumber = D("Order/OrderShipping")->field('track_number')->where(array('track_number' => array('IN', $getTrackNumber)))->find();
            if (!$trackNumber) {
                D("Order/OrderRecord")->addHistory($orderId, 8, 4,'导入运单号 '.$track_number);
                $return = D("Order/OrderShipping")->updateShipping($orderId, $getTrackNumber, $_POST['order_remark']);
            } else {
                $implodeTraNu = $trackNumber ? implode(',', $trackNumber) : '';
                $return = array('status' => 0, 'message' => $implodeTraNu . '此跟踪号已经使用。');
            }
        } else {
            $return = array('status' => 0, 'message' => '订单号或订单ID不能为空。');
        }
        add_system_record(sp_get_current_admin_id(), 2, 4, '填写物流跟踪号发货，修改DF订单状态为发货');

        echo json_encode($return);
        exit();
    }
    
    /**
     * 要求取消订单
     */
    public function cancelOrder(){
        try{
            $orderId = I('post.order_id');
            D("Order/Order")->where('id_order='.$orderId)->save(array('id_order_status'=>14));
            D("Order/OrderRecord")->addHistory($orderId,14,3,'【仓储管理取消】 '.$_POST['comment']);
            $status = 1; $message = '';
        }catch (\Exception $e){
            $status = 1; $message = $e->getMessage();
        }
        add_system_record(sp_get_current_admin_id(), 2, 4, '要求取消DF订单');
        echo json_encode(array('status'=>$status,'message'=>$message));
    }

    public function export_excel() {
        set_time_limit(0);
        ini_set('memory_limit', '-1');

        vendor("PHPExcel.PHPExcel");
        vendor("PHPExcel.PHPExcel.IOFactory");
        $excel = new \PHPExcel();

        $column = array(
            '地区', '域名', '订单号', '姓名', '电话号码', '邮箱',
            '产品名和价格', '属性', 'SKU', '总价（NTS）', '产品数量',
            '送货地址', '订单数量', '留言备注', '下单时间', '订单状态', '订单数',
            '发货日期'
        );
        $j = 65;
        foreach ($column as $col) {
            $excel->getActiveSheet()->setCellValue(chr($j) . '1', $col);
            ++$j;
        }
        //默认结束时间是当天
        //如果不默认的话会把当天以后发货日期的订单也导出来
        $where = array();
        $time_start = I('get.start_time');
        $time_end = I('get.end_time');
        $_GET['start_time'] = $time_start;
        $_GET['end_time'] = $time_end;
        $status_id = I('get.status_id');

        if (isset($_GET['user_province']) && $_GET['user_province']) {
            $where['province'] = array('EQ', $_GET['user_province']);
        }
        if ($status_id > 0) {
            $where[] = "`id_order_status` = '$status_id'";
        } else {
            $where[] = "`id_order_status` IN (8)";
        }
        if ($time_start)
            $where[] = "`created_at` >= '$time_start'"; //create_at
        if ($time_end)
            $where[] = "`created_at` < '$time_end'";
        if (isset($_GET['id_shipping']) && $_GET['id_shipping'] > 0) {
            $where[] = "`id_shipping` = $_GET[id_shipping]";
        }

        $M = new \Think\Model;
        $ordTable = D("Order/Order")->getTableName();
        $ordIteTable = D("Order/OrderItem")->getTableName();

        $model = D('Order/Order');

        //$orderList = $model->field('*')->where($where)->order("delivery_date asc,user_tel DESC,user_name desc,user_email desc")->select();
        $orderList = $M->table($ordTable . ' AS o LEFT JOIN ' . $ordIteTable . ' AS oi ON o.id_order=oi.id_order')->field('o.*')
                ->where($where)->order('oi.id_product,oi.id_product_sku desc')->group('oi.id_order')
//                ->fetchSql(true)
                ->limit(10000)->select();

        $order_item = D('Order/OrderItem');
        foreach ($orderList as $key => $o) {
            $orderList[$key]['products'] = $order_item->get_item_list($o['id_order']);

            /*if (in_array($o['id_order_status'], array(4, 6))) {//修改订单为配货中，并且写入导出记录
                $model->where('id_order=' . $o['id_order'])->save(array('id_order_status' => 5)); // 5 配货中
                D("Order/OrderRecord")->addHistory($o['id'], 5,5, '订单列表导出');
            }*/
        }
        $orders = $orderList;
        
        $result = D('Order/OrderStatus')->cache(true, 3600)->select();
        $status = array();
        foreach ($result as $statu) {
            $status[(int) $statu['id_order_status']] = $statu;
        }
        /** @var \Order\Model\OrderItemModel $order_item */
        $order_item = D('Order/OrderItem');
        $idx = 2;
        $data = array();
        $productSku = D('Common/ProductSku');
        foreach ($orders as $o) {
            $product_name = '';
            $attrs = '';
            $skuString = '';
            $products = $order_item->get_item_list($o['id_order']);
            $web = D('Common/Domain')->field('name')->where(array('id_domain'=>$o['id_domain']))->find();
            $qty = 0;
            foreach ($products as $p) {
                $product_name .= $p['product_title'] . "\n";
                $qty += $p['quantity'];
                if ($p['id_product_sku']) {
                    $getSkuObj = $productSku->cache(true, 3600)->find($p['id_product_sku']);
                    $skuString .= $getSkuObj['model'] . '   ';
                } else {
                    $skuString .= '';
                }

                if (isset($p['order_attrs']))
                    foreach ($p['order_attrs'] as $a) {
                        unset($a['number']);
                        foreach ($a as $av) {
                            $attrs .= $av['title'] . ' x ';
                        }
                        $attrs .= $p['qty'] . "\n";
                    }
            }
            $status_name = isset($status[$o['id_order_status']]) ? $status[$o['id_order_status']]['title'] : '未知';
            $address = $o['city'] . ' ' . $o['area'] . ' ' . $o['address'];
            $dataKey = md5($skuString);
            $data[][$dataKey] = array(
                $o['province'], $web['name'], $o['id_increment'], $o['first_name'], $o['tel'], $o['email'],
                $product_name, $attrs, $skuString, $o['price_total'], $qty,
                $address, $o['order_count'], $o['remark'], $o['created_at'], $status_name, $o['order_repeat'],
                ''
            );
            /* $j = 65;
              foreach ($data as $col) {
              $excel->getActiveSheet()->setCellValue(chr($j).$idx, $col);
              ++$j;
              }
              ++$idx; */

            if (in_array($o['id_order_status'], array(4, 6))) {//修改订单为配货中，并且写入导出记录
                $model->where('id=' . $o['id'])->save(array('status_id' => 5)); // 18 配货中
                D("Order/OrderRecord")->addHistory($o['id'], 5,5, '导出未配货订单');
            }
        }
        if ($data) {
            foreach ($data as $items) {
                if (is_array($items)) {
                    foreach ($items as $item) {
                        $j = 65;
                        foreach ($item as $col) {
                            $excel->getActiveSheet()->setCellValue(chr($j) . $idx, $col);
                            ++$j;
                        }
                        ++$idx;
                    }
                }
            }
        }
        add_system_record(sp_get_current_admin_id(), 2, 4, '导出出货信息表');
        $excel->getActiveSheet()->setTitle(date('Y-m-d') . '出货信息表.xlsx');
        $excel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . date('Y-m-d') . '出货信息表.xlsx');
        header('Cache-Control: max-age=0');
        $writer = \PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
        $writer->save('php://output');
    }
    
    //导出未配货订单
    public function exportsearch(){
        set_time_limit(0);
        $M = new \Think\Model;
        /** @var $ordModel \Common\Model\OrderModel*/
        $ordModel = D("Order/Order");
        $allStatus = $ordModel->getStatusLabel();
        $getFormWhere = $ordModel->form_where($_GET);
        $getFormWhere['status_id'] = array('IN',array(4,5,6));
        //$getFormWhere['shipping_id'] = array('NEQ','');
        if($_GET['product_id']){
            $M = new \Think\Model;
            $ordName = $ordModel->getTableName();
            $ordIteName = D("Order/OrderItem")->getTableName();
            $findOrder = $M->table($ordName.' AS o LEFT JOIN '.$ordIteName.' AS oi ON o.id_order=oi.id_order')->field('o.id_order')
                ->where(array('oi.id_product'=>$_GET['product_id'],'o.id_order_status'=>array('IN',array(4,5,6))))
                ->group('oi.id_order')->limit(5000)->select();
            $allId = array_column($findOrder,'id_order');
            $getFormWhere['id'] = $allId?array('IN',$allId):array('IN',array(0));
        }
        $orderList = $ordModel->where($getFormWhere)
            ->where(array(
                'id' => '10086682'
            ))
            ->order("date_delivery asc, created_at ASC")
            //->fetchSql(true)
            ->select();

        
        vendor("PHPExcel.PHPExcel");vendor("PHPExcel.PHPExcel.IOFactory");//vendor("PHPExcel.PHPExcel.Writer.CSV");
        $objPHPExcel = new \PHPExcel();
        $getField = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC');
        $setRowName = array('日期','订单号','状态','物流公司','网络渠道','类型','订单重量','运单号','物流账号','收件人'
        ,'收件人电话','物品名称','件数','SKU','属性','物品数量','代收款','地址','备注');
        foreach($setRowName as $r=>$v){
            $objPHPExcel->setActiveSheetIndex(0)->setCellValue($getField[$r].'1',$v);
        }
        /* @var $orderItem \Common\Model\OrderItemModel*/
        $orderItem = D('Order/OrderItem');
        $ordShiTable =  D('Common/OrderShipping')->getTableName();
        $shiTable    =  D('Common/Shipping')->getTableName();
        $num  = 2;
        foreach ($orderList as $k => $v) {
            $orderId = $v['id_order'];
            $products = $orderItem->get_item_list($v['id_order']);
        
            $address = $v['province'] . ' ' . $v['city'] . ' ' . $v['area'] . ' ' . $v['address'];
            $getShipping = $M->table($ordShiTable . ' AS os left join  ' . $shiTable . ' AS s on os.id_shipping=s.id_shipping ')
                ->field('s.id_shipping,s.title,s.channels,s.account,os.track_number')
                ->where("os.id_order=" . $orderId)->select();
            $shippingName = $getShipping ? $getShipping[0]['title'] : '';
            $channels = $getShipping ? $getShipping[0]['channels'] : '';
            $account = $getShipping ? $getShipping[0]['account'] : '';
            $trackNumber = $getShipping ? array_column($getShipping, 'track_number') : '';
            $trackNumber = $trackNumber ? implode(',', $trackNumber) : '';
            $countPro = 1;
            $getProTotal = count($products);
            foreach ($products as $product) {
                $proTitle = $product['title']?$product['title']:$product['product_title'];
                $proId = $product['id_product'];
                $attrArr = array();
                //if($v['id']=='10080188'){
                //print_r($product);exit();
                //}
                if ($product['order_attrs']) {
                    foreach ($product['order_attrs'] as $pa) {
                        $number = $product['qty']; //$number=$pa['number'];
                        unset($pa['number']);
                        $tempAttrArray = array();
                        foreach ($pa as $pa2) {
                            $tempAttrArray[] = $pa2['value_label'];
                        }
                        $attrArr[] = $tempAttrArray ? implode(' * ', $tempAttrArray) : '';
                    }
                }
                $attr = $attrArr ? implode(' ', $attrArr) : '';
                //$setRowName = array('日期','订单号','状态','物流公司','网络渠道','类型','订单重量','运单号','物流账号','收件人'
                //,'收件人电话','物品名称','件数','SKU','属性','物品数量','代收款','地址','备注');
                $weight = '';
                $sku = isset($product['id_product_sku']) && $product['id_product_sku'] ? D('Common/ProductSku')->field('model')->getField('model') : '';
                $tempOrderId = $getProTotal > 1 ? $v['id_order'] . '-' . $countPro . '/' . $getProTotal : $v['id_order'];
                $bodyRow = array(
                    date('Y-m-d', strtotime($v['created_at'])),
                    $tempOrderId,
                    $allStatus[$v['id_order_status']],
                    $shippingName, $channels,
                    $v['province'], $weight, $trackNumber, $account,
                    $v['name'], $v['tel'],//'\''.
                    $proTitle, $v['order_count'], $sku, $attr, $product['quantity'],
                    $v['price_total'],
                    $address, $v['remark']
                );
                
                foreach ($bodyRow as $row => $value) {
                    $objPHPExcel->setActiveSheetIndex(0)->setCellValue($getField[$row] . $num, $value);
                }
                $num++;
                $countPro++;
            }
            //if(count($products)==0){$num++;}//没有产品，输出空行
            if (in_array($v['id_order_status'], array(4, 6))) {//修改订单为配货中，并且写入导出记录
                $ordModel->where('id=' . $orderId)->save(array('status_id' => 5));// 18 配货中
                $comment = '导出未配货订单';
                D("Order/OrderRecord")->addHistory($orderId, 5,5, $comment);
            }
        }
        add_system_record(sp_get_current_admin_id(), 2, 4, '导出未配货订单');
        $objPHPExcel->getActiveSheet()->setTitle('order');
        $objPHPExcel->setActiveSheetIndex(0);
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="'.date('YmdHis').'.xlsx"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
        exit;
    }

}
