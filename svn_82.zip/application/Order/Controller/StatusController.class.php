<?php
/**
 * 订单统计
 * @Author morrowind
 * @qq 752979972
 * Class IndexController
 * @package Order\Controller
 */
namespace Order\Controller;
use Common\Controller\AdminbaseController;
use Think\Event;
use Think\Hook;
use Order\Model\UpdateStatusModel;
class StatusController extends AdminbaseController{
	protected $order,$page;
	public function _initialize() {
		parent::_initialize();
		$this->order=D("Order/Order");
        $this->page      = $_SESSION['set_page_row']?(int)$_SESSION['set_page_row']:20;
	}

    /**
     * 未处理订单，初步审核订单后，订单进入待审核列表
     */
    public function update_status(){
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        /** @var \Order\Model\UpdateStatusModel $update_status */
        $update_status = D('Order/UpdateStatus');
        $order_ids = is_array($_POST['order_id'])?$_POST['order_id']:array($_POST['order_id']);
        $action = $_POST['action'];
        $comment   =  $_POST['order_remark']?:'';
        $message = array();
        foreach($order_ids as $id){
            $orderId = (int)$id;
            switch($action){
                case 1:case 2:
                    //TODO:事件点--订单审核通过
                    $result = $model->approved($orderId,3,$comment);//2为order_status 待发货状态ID
                    break;
                break;
                case 3:
                //TODO:事件点--订单取消
                $invalid_status = $action==2?10:$_POST['invalid_status'];
                $update_data = array('id'=>$orderId,'status_id'=>$invalid_status,'comment'=>$comment);
                $result = UpdateStatusModel::cancel($update_data);
                break;
            }
            if(!$result){
                $message[]  = $id.'此订单状态不能执行此操作  ';
            }
        }
        $status = count($message) ? 0 : 1;
        $message = count($message) ? implode('   ', $message) : '修改成功';
        add_system_record(sp_get_current_admin_id(), 2, 4, '更新未处理DF订单');
        $return = array('status' => $status, 'message' => $message);
        echo json_encode($return);exit();
    }
    /**
     * 未处理订单
     */
    public function untreated(){
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $set_where = array('id_order_status'=>1);
        $data = $model->get_untreated_order($set_where);
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $data['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page",$data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data['order_total']);
        //$this->assign("todayWebData", $data['todayWebData']);
        $this->assign("order_list",$data['order_list']);
        $this->assign("shipping",$data['shipping']);
        $this->assign("all_product",$data['allProduct']);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看未处理DF订单');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("all_zone", $data['all_zone']);
        $this->display();
    }

    /**
     * 待审核订单
     */
    public function unapproved(){
        $where = array('id_order_status'=>3);//array('IN',array(2))
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $data = $model->get_untreated_order($where);
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $data['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page",$data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data['order_total']);
        $this->assign("today_web_data", $data['today_web_data']);
        $this->assign("order_list",$data['order_list']);
        $this->assign("shipping",$data['shipping']);
        $this->assign("all_product",$data['all_product']);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看待审核DF订单');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("all_zone", $data['all_zone']);
        $this->display();
    }

    /**
     * 今日处理
     */
    public function today_process(){
        $where = array();
        $id_order_status = I('get.status_id');
        if ($id_order_status > 0) {
            $where['id_order_status'] = array('EQ',$id_order_status);
        } else {
            $where['id_order_status'] =  array('IN', array(3,4,10,11,12,13,14,15));
        }
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $data = $model->get_untreated_order($where);
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $data['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page",$data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data['order_total']);
        //$this->assign("todayWebData", $data['todayWebData']);
        $this->assign("order_list",$data['order_list']);
        $this->assign("shipping",$data['shipping']);
        $this->assign("all_product",$data['all_product']);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看已处理DF订单');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("all_zone", $data['all_zone']);
        $this->display();
    }
    /**
     * 无效订单
     */
    public function invalid(){
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $where = array();
        $id_order_status = I('get.status_id');
        if ($id_order_status > 0) {
            $where['id_order_status'] = array('EQ', $id_order_status);
        } else {
            $where['id_order_status'] =  array('IN', array(11, 12,13, 14, 15));
        }
        $result = $model->get_untreated_order($where);
        $department_id  = $_SESSION['department_id'];
        $all_product = D('Common/Product')->field('id_product,title')->order('id_product desc')->cache(true, 86400)->select();
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $result['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $result['form_data']);
        $this->assign("page", $result['page']);
        $this->assign("today_total", $result['today_total']);
        $this->assign("order_total", $result['order_total']);
        $this->assign("today_web_data", $result['today_web_data']);
        $this->assign("order_list", $result['order_list']);
        $this->assign("shipping", $result['shipping']);
        $this->assign("all_product", $all_product);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus')->where(array('id_order_status'=>array('IN',array(11, 12,13, 14, 15))))->select();
        $status_model = array_column($status_model, 'title', 'id_order_status');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看无效DF订单');
        $this->assign('status_list',$status_model);
        $this->assign("all_zone", $result['all_zone']);
        $this->display();
    }

    /**
     * 待审核订单
     */
    public function pending(){
        $where = array('id_order_status'=>3);
        /** @var \Order\Model\OrderStatusModel $model */
        $model = D('Order/OrderStatus');
        $data= $model->get_untreated_order($where);
        $department_id  = $_SESSION['department_id'];
        $department  = D('Department/Department')->where('type=1')->cache(true,3600)->select();
        $department  = $department?array_column($department,'title','id_department'):array();
        $this->assign("department_id", $department_id);
        $this->assign("department", $department);
        $this->assign("advertiser", $data['advertiser']);
        $this->assign("get_data", $_GET);
        $this->assign("form_data", $data['form_data']);
        $this->assign("page",$data['page']);
        $this->assign("today_total", $data['today_total']);
        $this->assign("order_total", $data['order_total']);
        $this->assign("today_web_data", $data['today_web_data']);
        $this->assign("order_list",$data['order_list']);
        $this->assign("shipping",$data['shipping']);
        $this->assign("all_product",$data['all_product']);
        /** @var \Order\Model\OrderStatusModel $status_model */
        $status_model = D('Order/OrderStatus');
        add_system_record(sp_get_current_admin_id(), 4, 4, '查看待审核DF订单');
        $this->assign('status_list',$status_model->get_status_label());
        $this->assign("all_zone", $data['all_zone']);
        $this->display();
    }

    /**
     * AJXA提交通过审核订单
     */
    public function approved(){
        /* @var $order \Common\Model\OrderModel*/
        $order  = D("Common/Order");
        $order_ids   = is_array($_POST['order_id'])?$_POST['order_id']:array($_POST['order_id']);
        $comment   =  $_POST['order_remark'];
        //$shippingIds = $_POST['shippingIds'];//订单审核时， 现在要求去掉物流
        try{
            foreach($order_ids as $id){
                $order_id = (int)$id;
                $status_id = 4;
                $update_data = array(
                    'id_order'=>$order_id,
                    'status_id'=>$status_id,
                    'comment'=>$comment
                );
                UpdateStatusModel::approved($update_data);
                //$order->where('id='.$orderId)->save($updateData);
                D("Order/OrderRecord")->addHistory($order_id,$status_id,4,$comment);
            }
            $status = 1;$message = '操作成功';
        }catch (\Exception $e){
            $message = $e->getMessage();
            $status = 0;
        }
        add_system_record(sp_get_current_admin_id(), 2, 4, '更新待审核DF订单');
        $return  = array('status'=>$status,'message'=>$message);
        echo json_encode($return);exit();
    }
    
    
    /*
     * 临时更新状态
     */
    public function update_demo() {
        $infor = array(
            'error' => array(),
            'warning' => array(),
            'success' => array()
        );
        $total = 0;
        $ord = D('Order/Order');
        if (IS_POST) {
            $data = I('post.data');      
            $data = $this->getDataRow($data);
            $count = 1;
            foreach ($data as $row) {
                $row = trim($row);
                if (empty($row))
                    continue;
                ++$total;
                $row = explode("\t", trim($row), 1);
                $order = $ord->where(array(
                    'id_increment' => trim($row[0])
                    ))
                    ->find();
            
                if($order  && $order['id_order']){  
                    $order_id = $order['id_order'];
                    D("Order/Order")->where(array(
                    'id_order' => $order_id
                    ))->save(array('id_order_status' => 4));
                    $infor['success'][] = sprintf('第%s行: 订单号:%s 更新状态: %s', $count++, $row[0],'未配货');
                }else{
                    $infor['error'][] = sprintf('第%s行: 没有找到订单', $count++);
                }                
            }
        }
        $this->assign('infor', $infor);
        $this->assign('data', I('post.data'));
        $this->assign('total', $total);
        $this->display();
    }
}